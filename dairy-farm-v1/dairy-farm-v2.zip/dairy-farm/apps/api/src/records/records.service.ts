import { BadRequestException, Injectable } from '@nestjs/common';
import { Prisma, RecordScope } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../common/audit.service';
import { InventoryService } from '../inventory/inventory.service';
import { CreateExpenseDto, CreateFeedDto, CreateMilkDto, CreateSaleDto } from './records.dto';

function assertScope(scope: RecordScope, groupId?: string, animalId?: string) {
  const bad =
    (scope === 'HERD' && (groupId || animalId)) ||
    (scope === 'GROUP' && (!groupId || animalId)) ||
    (scope === 'ANIMAL' && (!animalId || groupId));
  if (bad) throw new BadRequestException(`References do not match scope ${scope}`);
}

@Injectable()
export class RecordsService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
    private inventory: InventoryService,
  ) {}

  // ==================== MILK ====================
  async createMilk(farmId: string, userId: string, dto: CreateMilkDto) {
    assertScope(dto.scope, dto.groupId, dto.animalId);
    const date = new Date(dto.date);

    // V2: auto-quarantine milk from animals currently under withdrawal.
    // Only applies to ANIMAL-scope entries; HERD/GROUP totals are the
    // farmer's aggregate and the withdrawal check happens at the animal
    // level before the milk goes into the herd tank in practice.
    let quarantined = false;
    if (dto.scope === 'ANIMAL' && dto.animalId) {
      const active = await this.prisma.$queryRaw<Array<{ id: string }>>(Prisma.sql`
        SELECT id FROM "Treatment"
        WHERE "farmId" = ${farmId}::uuid
          AND "animalId" = ${dto.animalId}::uuid
          AND "withdrawalDays" > 0
          AND date <= ${date}
          AND (date + ("withdrawalDays" || ' days')::interval)::date >= ${date}
        LIMIT 1
      `);
      quarantined = active.length > 0;
    }

    const rec = await this.prisma.milkRecord.create({
      data: {
        farmId,
        date,
        session: dto.session,
        scope: dto.scope,
        groupId: dto.groupId,
        animalId: dto.animalId,
        liters: dto.liters,
        quarantined,
        createdById: userId,
      },
    });
    await this.audit.log({
      farmId, userId, action: 'milk.create', entity: 'MilkRecord', entityId: rec.id, data: dto,
    });
    return rec;
  }

  listMilk(farmId: string, from: string, to: string) {
    return this.prisma.milkRecord.findMany({
      where: { farmId, date: { gte: new Date(from), lte: new Date(to) } },
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
    });
  }

  // ==================== FEED ====================
  // V2: if itemId is supplied, cost is derived from inventory (weighted avg).
  // Backward-compatible: leaving itemId out preserves the V1 manual-cost flow.
  async createFeed(farmId: string, userId: string, dto: CreateFeedDto) {
    assertScope(dto.scope, dto.groupId, dto.animalId);

    return this.prisma.$transaction(async (tx) => {
      let costCents = dto.costCents ?? 0;
      let itemId = dto.itemId;

      if (itemId && dto.quantityKg > 0) {
        // Draw from stock; use the returned cost (WAC * qty) as the record's cost.
        const { costCents: drawnCost } = await this.inventory.consumeInTx(
          tx,
          farmId,
          userId,
          {
            itemId,
            date: dto.date,
            quantity: dto.quantityKg,
            linkedEntity: 'FeedRecord',
            note: `Feed: ${dto.feedType}`,
          },
        );
        costCents = drawnCost;
      }

      const rec = await tx.feedRecord.create({
        data: {
          farmId,
          date: new Date(dto.date),
          scope: dto.scope,
          groupId: dto.groupId,
          animalId: dto.animalId,
          feedType: dto.feedType,
          quantityKg: dto.quantityKg,
          costCents,
          itemId,
          createdById: userId,
        },
      });
      await this.audit.log({
        farmId, userId, action: 'feed.create', entity: 'FeedRecord', entityId: rec.id, data: dto,
      });
      return rec;
    });
  }

  listFeed(farmId: string, from: string, to: string) {
    return this.prisma.feedRecord.findMany({
      where: { farmId, date: { gte: new Date(from), lte: new Date(to) } },
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
    });
  }

  // ==================== EXPENSES ====================
  async createExpense(farmId: string, userId: string, dto: CreateExpenseDto) {
    const rec = await this.prisma.expense.create({
      data: {
        farmId,
        date: new Date(dto.date),
        category: dto.category,
        amountCents: dto.amountCents,
        note: dto.note,
        supplierId: dto.supplierId,
        createdById: userId,
      },
    });
    await this.audit.log({
      farmId, userId, action: 'expense.create', entity: 'Expense', entityId: rec.id, data: dto,
    });
    return rec;
  }

  listExpenses(farmId: string, from: string, to: string) {
    return this.prisma.expense.findMany({
      where: { farmId, date: { gte: new Date(from), lte: new Date(to) } },
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
    });
  }

  // ==================== SALES ====================
  // V2: sales optionally link to a Customer. Price defaults to the customer's
  // agreed price if the DTO doesn't override.
  async createSale(farmId: string, userId: string, dto: CreateSaleDto) {
    let priceCentsPerLiter = dto.priceCentsPerLiter;
    let customerName = dto.customerName ?? 'Walk-in';

    if (dto.customerId) {
      const cust = await this.prisma.customer.findUnique({
        where: { id: dto.customerId, farmId },
      });
      if (!cust) throw new BadRequestException('Customer not found');
      customerName = cust.name;
      if (!priceCentsPerLiter && cust.priceCentsPerLiter) {
        priceCentsPerLiter = cust.priceCentsPerLiter;
      }
    }
    if (!priceCentsPerLiter || priceCentsPerLiter < 1) {
      throw new BadRequestException('Price per liter is required (no default set for this customer)');
    }

    const rec = await this.prisma.sale.create({
      data: {
        farmId,
        date: new Date(dto.date),
        liters: dto.liters,
        priceCentsPerLiter,
        customerName,
        customerId: dto.customerId,
        paid: dto.paid,
        createdById: userId,
      },
    });
    await this.audit.log({
      farmId, userId, action: 'sale.create', entity: 'Sale', entityId: rec.id, data: dto,
    });
    return rec;
  }

  listSales(farmId: string, from: string, to: string) {
    return this.prisma.sale.findMany({
      where: { farmId, date: { gte: new Date(from), lte: new Date(to) } },
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
      include: { customer: { select: { id: true, name: true } } },
    });
  }

  markSalePaid(farmId: string, id: string) {
    return this.prisma.sale.update({ where: { id, farmId }, data: { paid: true } });
  }

  // V2: list unpaid, uninvoiced sales for a specific customer — used by
  // the "invoice these sales" workflow.
  listUninvoicedForCustomer(farmId: string, customerId: string) {
    return this.prisma.sale.findMany({
      where: { farmId, customerId, invoiceId: null, paid: false },
      orderBy: { date: 'asc' },
    });
  }
}
