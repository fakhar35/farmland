import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard, AuthedRequest } from '../common/auth.guard';
import { FarmRoleGuard } from '../common/farm-role.guard';
import { CreateTreatmentDto, CreateVaccinationDto } from './health.dto';
import { HealthService } from './health.service';

@Controller('farms/:farmId/health')
@UseGuards(AuthGuard, FarmRoleGuard)
export class HealthController {
  constructor(private health: HealthService) {}

  @Get('vaccinations')
  listVax(@Param('farmId') farmId: string, @Query('animalId') animalId?: string) {
    return this.health.listVaccinations(farmId, animalId);
  }

  @Get('treatments')
  listTreatments(
    @Param('farmId') farmId: string,
    @Query('animalId') animalId?: string,
    @Query('activeOnly') activeOnly?: string,
  ) {
    return this.health.listTreatments(farmId, animalId, activeOnly === 'true');
  }

  @Get('withdrawals')
  withdrawals(@Param('farmId') farmId: string) {
    return this.health.animalsUnderWithdrawal(farmId);
  }

  @Post('vaccinations')
  createVax(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: CreateVaccinationDto) {
    return this.health.createVaccination(farmId, req.user!.sub, dto);
  }

  @Post('treatments')
  createTreatment(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: CreateTreatmentDto) {
    return this.health.createTreatment(farmId, req.user!.sub, dto);
  }

  @Post('treatments/:id/resolve')
  resolve(@Param('farmId') farmId: string, @Param('id') id: string, @Req() req: AuthedRequest) {
    return this.health.resolveTreatment(farmId, req.user!.sub, id);
  }
}
