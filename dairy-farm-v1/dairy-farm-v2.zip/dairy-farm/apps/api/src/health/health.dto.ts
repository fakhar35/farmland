import { IsInt, IsISO8601, IsNumber, IsOptional, IsString, IsUUID, Min, MinLength } from 'class-validator';

export class CreateVaccinationDto {
  @IsUUID() animalId: string;
  @IsString() @MinLength(1) vaccine: string;
  @IsISO8601() date: string;
  @IsOptional() @IsISO8601() nextDueDate?: string;
  @IsOptional() @IsUUID() itemId?: string;
  @IsOptional() @IsNumber() @Min(0.001) doseQty?: number;
  @IsOptional() @IsString() notes?: string;
}

export class CreateTreatmentDto {
  @IsUUID() animalId: string;
  @IsString() @MinLength(1) condition: string;
  @IsString() @MinLength(1) medicine: string;
  @IsISO8601() date: string;
  @IsOptional() @IsInt() @Min(0) withdrawalDays?: number;
  @IsOptional() @IsISO8601() followUpDate?: string;
  @IsOptional() @IsUUID() itemId?: string;
  @IsOptional() @IsNumber() @Min(0.001) doseQty?: number;
  @IsOptional() @IsString() notes?: string;
}
