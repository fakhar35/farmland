import { Injectable, NotFoundException } from '@nestjs/common';
import { InventoryCategory, Prisma, ReminderKind, ReminderStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../common/audit.service';
import { InventoryService } from '../inventory/inventory.service';
import { CreateTreatmentDto, CreateVaccinationDto } from './health.dto';

// ---------------------------------------------------------------
// Health module
//
// Vaccinations: record a dose, optionally schedule the next due date,
// and (if linked to a medicine InventoryItem) draw from stock at WAC.
// A nextDueDate creates a Reminder that shows up in the daily brief.
//
// Treatments: same medicine-inventory link, plus a withdrawal window.
// Any ANIMAL-scope milk record on that animal within `withdrawalDays`
// of the treatment date gets flagged `quarantined: true` and is
// excluded from sale-eligible totals in reports.
// ---------------------------------------------------------------

@Injectable()
export class HealthService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
    private inventory: InventoryService,
  ) {}

  // ---- reads ----

  listVaccinations(farmId: string, animalId?: string) {
    return this.prisma.vaccination.findMany({
      where: { farmId, ...(animalId ? { animalId } : {}) },
      orderBy: { date: 'desc' },
      include: { animal: { select: { id: true, tag: true, name: true } } },
    });
  }

  listTreatments(farmId: string, animalId?: string, activeOnly = false) {
    return this.prisma.treatment.findMany({
      where: {
        farmId,
        ...(animalId ? { animalId } : {}),
        ...(activeOnly ? { resolved: false } : {}),
      },
      orderBy: { date: 'desc' },
      include: { animal: { select: { id: true, tag: true, name: true } } },
    });
  }

  // Animals currently under milk withdrawal — for the dashboard banner.
  async animalsUnderWithdrawal(farmId: string) {
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);
    // Postgres date arithmetic: treatment.date + withdrawalDays >= today
    const treatments = await this.prisma.$queryRaw<
      Array<{ animalId: string; tag: string; endDate: Date; medicine: string }>
    >(Prisma.sql`
      SELECT t."animalId", a.tag, (t.date + (t."withdrawalDays" || ' days')::interval)::date AS "endDate", t.medicine
      FROM "Treatment" t
      JOIN "Animal" a ON a.id = t."animalId"
      WHERE t."farmId" = ${farmId}::uuid
        AND t."withdrawalDays" > 0
        AND (t.date + (t."withdrawalDays" || ' days')::interval)::date >= ${today}
      ORDER BY "endDate" DESC
    `);
    return treatments;
  }

  // ---- vaccinations ----

  async createVaccination(farmId: string, userId: string, dto: CreateVaccinationDto) {
    return this.prisma.$transaction(async (tx) => {
      const animal = await tx.animal.findUnique({ where: { id: dto.animalId, farmId } });
      if (!animal) throw new NotFoundException('Animal not found');

      const vaccination = await tx.vaccination.create({
        data: {
          farmId,
          animalId: dto.animalId,
          vaccine: dto.vaccine,
          date: new Date(dto.date),
          nextDueDate: dto.nextDueDate ? new Date(dto.nextDueDate) : null,
          itemId: dto.itemId,
          doseQty: dto.doseQty != null ? new Prisma.Decimal(dto.doseQty) : null,
          notes: dto.notes,
          createdById: userId,
        },
      });

      // Draw the dose from medicine inventory if linked.
      if (dto.itemId && dto.doseQty) {
        await this.inventory.consumeInTx(tx, farmId, userId, {
          itemId: dto.itemId,
          date: dto.date,
          quantity: dto.doseQty,
          linkedEntity: 'Vaccination',
          linkedEntityId: vaccination.id,
          note: `${dto.vaccine} for ${animal.tag}`,
        });
      }

      // Queue a reminder for the next dose.
      if (dto.nextDueDate) {
        await tx.reminder.create({
          data: {
            farmId,
            kind: ReminderKind.VACCINATION,
            status: ReminderStatus.PENDING,
            title: `${dto.vaccine} due for ${animal.tag}`,
            dueDate: new Date(dto.nextDueDate),
            entity: 'Vaccination',
            entityId: vaccination.id,
            animalId: dto.animalId,
          },
        });
      }

      await this.audit.log({
        farmId, userId, action: 'health.vaccinate', entity: 'Vaccination', entityId: vaccination.id, data: dto,
      });
      return vaccination;
    });
  }

  // ---- treatments ----

  async createTreatment(farmId: string, userId: string, dto: CreateTreatmentDto) {
    return this.prisma.$transaction(async (tx) => {
      const animal = await tx.animal.findUnique({ where: { id: dto.animalId, farmId } });
      if (!animal) throw new NotFoundException('Animal not found');

      const treatment = await tx.treatment.create({
        data: {
          farmId,
          animalId: dto.animalId,
          condition: dto.condition,
          medicine: dto.medicine,
          date: new Date(dto.date),
          withdrawalDays: dto.withdrawalDays ?? 0,
          followUpDate: dto.followUpDate ? new Date(dto.followUpDate) : null,
          itemId: dto.itemId,
          doseQty: dto.doseQty != null ? new Prisma.Decimal(dto.doseQty) : null,
          notes: dto.notes,
          createdById: userId,
        },
      });

      if (dto.itemId && dto.doseQty) {
        await this.inventory.consumeInTx(tx, farmId, userId, {
          itemId: dto.itemId,
          date: dto.date,
          quantity: dto.doseQty,
          linkedEntity: 'Treatment',
          linkedEntityId: treatment.id,
          note: `${dto.medicine} for ${animal.tag}`,
        });
      }

      // Retroactive quarantine — any ANIMAL-scope milk already recorded
      // within the withdrawal window (e.g. same-day entry before treatment
      // was logged) gets flagged. Future entries are quarantined at write time.
      if (dto.withdrawalDays && dto.withdrawalDays > 0) {
        const start = new Date(dto.date);
        const end = new Date(dto.date);
        end.setDate(end.getDate() + dto.withdrawalDays);
        await tx.milkRecord.updateMany({
          where: {
            farmId,
            animalId: dto.animalId,
            date: { gte: start, lte: end },
            scope: 'ANIMAL',
          },
          data: { quarantined: true },
        });
      }

      if (dto.followUpDate) {
        await tx.reminder.create({
          data: {
            farmId,
            kind: ReminderKind.TREATMENT_FOLLOWUP,
            status: ReminderStatus.PENDING,
            title: `Follow-up: ${dto.condition} in ${animal.tag}`,
            dueDate: new Date(dto.followUpDate),
            entity: 'Treatment',
            entityId: treatment.id,
            animalId: dto.animalId,
          },
        });
      }

      await this.audit.log({
        farmId, userId, action: 'health.treat', entity: 'Treatment', entityId: treatment.id, data: dto,
      });
      return treatment;
    });
  }

  async resolveTreatment(farmId: string, userId: string, id: string) {
    const treatment = await this.prisma.treatment.update({
      where: { id, farmId },
      data: { resolved: true },
    });
    await this.audit.log({
      farmId, userId, action: 'health.resolve', entity: 'Treatment', entityId: id,
    });
    // Cancel any pending follow-up reminders.
    await this.prisma.reminder.updateMany({
      where: { farmId, entity: 'Treatment', entityId: id, status: ReminderStatus.PENDING },
      data: { status: ReminderStatus.DISMISSED, resolvedAt: new Date() },
    });
    return treatment;
  }
}
