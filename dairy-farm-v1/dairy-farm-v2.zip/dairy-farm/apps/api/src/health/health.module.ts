import { Module } from '@nestjs/common';
import { AuditService } from '../common/audit.service';
import { InventoryModule } from '../inventory/inventory.module';
import { HealthController } from './health.controller';
import { HealthService } from './health.service';

@Module({
  imports: [InventoryModule],  // for medicine consumption
  controllers: [HealthController],
  providers: [HealthService, AuditService],
})
export class HealthModule {}
