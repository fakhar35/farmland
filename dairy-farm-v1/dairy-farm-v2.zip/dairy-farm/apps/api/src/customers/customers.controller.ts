import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../common/auth.guard';
import { FarmRoleGuard } from '../common/farm-role.guard';
import { CreateCustomerDto, UpdateCustomerDto } from './customers.dto';
import { CustomersService } from './customers.service';

@Controller('farms/:farmId/customers')
@UseGuards(AuthGuard, FarmRoleGuard)
export class CustomersController {
  constructor(private customers: CustomersService) {}

  @Get()
  list(@Param('farmId') farmId: string, @Query('withBalances') withBalances?: string) {
    return withBalances ? this.customers.withBalances(farmId) : this.customers.list(farmId);
  }

  @Post()
  create(@Param('farmId') farmId: string, @Body() dto: CreateCustomerDto) {
    return this.customers.create(farmId, dto);
  }

  @Patch(':id')
  update(@Param('farmId') farmId: string, @Param('id') id: string, @Body() dto: UpdateCustomerDto) {
    return this.customers.update(farmId, id, dto);
  }
}
