import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCustomerDto, UpdateCustomerDto } from './customers.dto';

@Injectable()
export class CustomersService {
  constructor(private prisma: PrismaService) {}

  list(farmId: string, includeInactive = false) {
    return this.prisma.customer.findMany({
      where: { farmId, ...(includeInactive ? {} : { active: true }) },
      orderBy: { name: 'asc' },
    });
  }

  // A customer's outstanding balance is the sum of unpaid invoice remainders.
  async withBalances(farmId: string) {
    const customers = await this.list(farmId);
    const balances = await this.prisma.invoice.groupBy({
      by: ['customerId'],
      where: { farmId, status: { in: ['OPEN', 'PARTIAL'] } },
      _sum: { subtotalCents: true, paidCents: true },
    });
    const byId = new Map(balances.map((b) => [b.customerId, b]));
    return customers.map((c) => {
      const b = byId.get(c.id);
      const owed = (b?._sum.subtotalCents ?? 0) - (b?._sum.paidCents ?? 0);
      return { ...c, outstandingCents: Math.max(0, owed) };
    });
  }

  create(farmId: string, dto: CreateCustomerDto) {
    return this.prisma.customer.create({ data: { farmId, ...dto } });
  }

  update(farmId: string, id: string, dto: UpdateCustomerDto) {
    return this.prisma.customer.update({ where: { id, farmId }, data: dto });
  }
}
