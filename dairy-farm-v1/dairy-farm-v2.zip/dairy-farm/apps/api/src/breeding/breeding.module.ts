import { Module } from '@nestjs/common';
import { AuditService } from '../common/audit.service';
import { BreedingController } from './breeding.controller';
import { BreedingService } from './breeding.service';

@Module({
  controllers: [BreedingController],
  providers: [BreedingService, AuditService],
})
export class BreedingModule {}
