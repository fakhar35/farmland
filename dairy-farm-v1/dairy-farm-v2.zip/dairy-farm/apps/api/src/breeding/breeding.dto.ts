import { BreedingEventKind } from '@prisma/client';
import { IsEnum, IsISO8601, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateBreedingEventDto {
  @IsUUID() animalId: string;
  @IsEnum(BreedingEventKind) kind: BreedingEventKind;
  @IsISO8601() date: string;
  @IsOptional() @IsISO8601() nextDueDate?: string;
  @IsOptional() @IsString() outcome?: string;
  @IsOptional() @IsString() bullTag?: string;
  @IsOptional() @IsString() notes?: string;
}
