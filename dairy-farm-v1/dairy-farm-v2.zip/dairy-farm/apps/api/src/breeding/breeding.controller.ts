import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard, AuthedRequest } from '../common/auth.guard';
import { FarmRoleGuard } from '../common/farm-role.guard';
import { CreateBreedingEventDto } from './breeding.dto';
import { BreedingService } from './breeding.service';

@Controller('farms/:farmId/breeding')
@UseGuards(AuthGuard, FarmRoleGuard)
export class BreedingController {
  constructor(private breeding: BreedingService) {}

  @Get()
  list(@Param('farmId') farmId: string, @Query('animalId') animalId?: string) {
    return this.breeding.list(farmId, animalId);
  }

  @Post()
  create(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: CreateBreedingEventDto) {
    return this.breeding.create(farmId, req.user!.sub, dto);
  }
}
