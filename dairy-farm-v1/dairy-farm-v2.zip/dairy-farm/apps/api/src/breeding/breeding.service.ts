import { Injectable, NotFoundException } from '@nestjs/common';
import { BreedingEventKind, ReminderKind, ReminderStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../common/audit.service';
import { CreateBreedingEventDto } from './breeding.dto';

// Insemination triggers TWO reminders automatically:
//   - preg check ~30 days out
//   - calving   ~283 days out (bovine gestation)
// The user can override nextDueDate explicitly.
const PREG_CHECK_DAYS = 30;
const CALVING_DAYS = 283;

@Injectable()
export class BreedingService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
  ) {}

  list(farmId: string, animalId?: string) {
    return this.prisma.breedingEvent.findMany({
      where: { farmId, ...(animalId ? { animalId } : {}) },
      orderBy: { date: 'desc' },
      include: { animal: { select: { id: true, tag: true, name: true } } },
    });
  }

  async create(farmId: string, userId: string, dto: CreateBreedingEventDto) {
    return this.prisma.$transaction(async (tx) => {
      const animal = await tx.animal.findUnique({ where: { id: dto.animalId, farmId } });
      if (!animal) throw new NotFoundException('Animal not found');

      const event = await tx.breedingEvent.create({
        data: {
          farmId,
          animalId: dto.animalId,
          kind: dto.kind,
          date: new Date(dto.date),
          nextDueDate: dto.nextDueDate ? new Date(dto.nextDueDate) : null,
          outcome: dto.outcome,
          bullTag: dto.bullTag,
          notes: dto.notes,
          createdById: userId,
        },
      });

      if (dto.kind === BreedingEventKind.INSEMINATION) {
        const base = new Date(dto.date);
        const check = new Date(base);
        check.setDate(check.getDate() + PREG_CHECK_DAYS);
        const calving = new Date(base);
        calving.setDate(calving.getDate() + CALVING_DAYS);

        await tx.reminder.createMany({
          data: [
            {
              farmId,
              kind: ReminderKind.BREEDING_CHECK,
              status: ReminderStatus.PENDING,
              title: `Pregnancy check due for ${animal.tag}`,
              dueDate: check,
              entity: 'BreedingEvent',
              entityId: event.id,
              animalId: animal.id,
            },
            {
              farmId,
              kind: ReminderKind.CALVING_DUE,
              status: ReminderStatus.PENDING,
              title: `Expected calving for ${animal.tag}`,
              dueDate: calving,
              entity: 'BreedingEvent',
              entityId: event.id,
              animalId: animal.id,
            },
          ],
        });
      }

      await this.audit.log({
        farmId, userId, action: 'breeding.event', entity: 'BreedingEvent', entityId: event.id, data: dto,
      });
      return event;
    });
  }
}
