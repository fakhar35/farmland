import { Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { ReminderKind, ReminderStatus } from '@prisma/client';
import { AuthGuard, AuthedRequest } from '../common/auth.guard';
import { FarmRoleGuard } from '../common/farm-role.guard';
import { RemindersService } from './reminders.service';

@Controller('farms/:farmId/reminders')
@UseGuards(AuthGuard, FarmRoleGuard)
export class RemindersController {
  constructor(private reminders: RemindersService) {}

  @Get()
  list(
    @Param('farmId') farmId: string,
    @Query('windowDays') windowDays?: string,
    @Query('status') status?: ReminderStatus,
    @Query('kind') kind?: ReminderKind,
  ) {
    return this.reminders.list(farmId, {
      windowDays: windowDays ? Number(windowDays) : undefined,
      status,
      kind,
    });
  }

  @Post(':id/done')
  done(@Param('farmId') farmId: string, @Param('id') id: string, @Req() req: AuthedRequest) {
    return this.reminders.markDone(farmId, req.user!.sub, id);
  }

  @Post(':id/dismiss')
  dismiss(@Param('farmId') farmId: string, @Param('id') id: string, @Req() req: AuthedRequest) {
    return this.reminders.dismiss(farmId, req.user!.sub, id);
  }

  // Manual trigger for the sweeper, handy during development / demos.
  @Post('sweep')
  sweep() {
    return this.reminders.sweep();
  }
}
