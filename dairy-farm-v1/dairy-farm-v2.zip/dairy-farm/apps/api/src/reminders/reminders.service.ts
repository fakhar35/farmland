import { Injectable, OnModuleInit } from '@nestjs/common';
import { Queue, Worker } from 'bullmq';
import IORedis from 'ioredis';
import { ReminderKind, ReminderStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../common/audit.service';

// ---------------------------------------------------------------
// Reminders
//
// Reminders are DB rows created by other services (health, breeding,
// inventory). This service does two things beyond CRUD:
//
//  1. Scheduled sweep — a BullMQ repeatable job runs every hour and:
//     - marks PENDING reminders past their due date as OVERDUE
//     - creates LOW_STOCK reminders for items below reorderLevel
//       (idempotent — only if none already open for that item today)
//     - creates INVOICE_DUE reminders 2 days before an invoice's dueDate
//
//  2. On-demand list — the /reminders?window=... endpoint returns
//     reminders due within N days, used by the dashboard drawer.
//
// Everything is in the DB; the queue is scheduling only. If Redis is
// down the app still works — reminders just don't advance status
// automatically until the worker reconnects.
// ---------------------------------------------------------------

const QUEUE = 'dairy-reminders';
const SWEEP_JOB = 'sweep';

@Injectable()
export class RemindersService implements OnModuleInit {
  private queue?: Queue;
  private worker?: Worker;
  private redis?: IORedis;

  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
  ) {}

  async onModuleInit() {
    const url = process.env.REDIS_URL;
    if (!url) {
      // eslint-disable-next-line no-console
      console.warn('[reminders] REDIS_URL not set — reminder sweeper disabled');
      return;
    }
    // maxRetriesPerRequest: null is required by BullMQ workers
    this.redis = new IORedis(url, { maxRetriesPerRequest: null });
    this.queue = new Queue(QUEUE, { connection: this.redis });

    // Repeatable hourly sweep. { pattern } uses cron syntax.
    await this.queue.add(SWEEP_JOB, {}, {
      repeat: { pattern: '0 * * * *' },
      removeOnComplete: true,
      removeOnFail: 100,
    });

    this.worker = new Worker(
      QUEUE,
      async (job) => {
        if (job.name === SWEEP_JOB) await this.sweep();
      },
      { connection: this.redis },
    );

    this.worker.on('failed', (job, err) => {
      // eslint-disable-next-line no-console
      console.error(`[reminders] job ${job?.id} failed:`, err);
    });

    // eslint-disable-next-line no-console
    console.log('[reminders] BullMQ worker started, hourly sweep scheduled');
  }

  // ---- reads ----

  list(
    farmId: string,
    opts: { windowDays?: number; status?: ReminderStatus; kind?: ReminderKind } = {},
  ) {
    const to = new Date();
    to.setDate(to.getDate() + (opts.windowDays ?? 30));
    return this.prisma.reminder.findMany({
      where: {
        farmId,
        ...(opts.status ? { status: opts.status } : { status: { in: ['PENDING', 'OVERDUE'] } }),
        ...(opts.kind ? { kind: opts.kind } : {}),
        dueDate: { lte: to },
      },
      orderBy: [{ status: 'asc' }, { dueDate: 'asc' }],
      take: 200,
    });
  }

  async markDone(farmId: string, userId: string, id: string) {
    const r = await this.prisma.reminder.update({
      where: { id, farmId },
      data: { status: ReminderStatus.DONE, resolvedAt: new Date() },
    });
    await this.audit.log({ farmId, userId, action: 'reminder.done', entity: 'Reminder', entityId: id });
    return r;
  }

  async dismiss(farmId: string, userId: string, id: string) {
    const r = await this.prisma.reminder.update({
      where: { id, farmId },
      data: { status: ReminderStatus.DISMISSED, resolvedAt: new Date() },
    });
    await this.audit.log({ farmId, userId, action: 'reminder.dismiss', entity: 'Reminder', entityId: id });
    return r;
  }

  // ---- sweeper ----

  // Public so it can be called manually for testing without waiting an hour.
  async sweep(): Promise<{ overdue: number; lowStock: number; invoiceDue: number }> {
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);

    // 1. Advance PENDING past due to OVERDUE.
    const overdue = await this.prisma.reminder.updateMany({
      where: { status: ReminderStatus.PENDING, dueDate: { lt: today } },
      data: { status: ReminderStatus.OVERDUE },
    });

    // 2. Low stock — one reminder per item that's below reorder level and
    //    doesn't already have an open reminder.
    const lowItems = await this.prisma.inventoryItem.findMany({
      where: {
        active: true,
        reorderLevel: { not: null },
        // Prisma can't compare two columns directly; filter in memory below.
      },
      select: { id: true, farmId: true, name: true, quantityOnHand: true, reorderLevel: true },
    });
    let lowStockCreated = 0;
    for (const item of lowItems) {
      if (item.reorderLevel == null) continue;
      if (Number(item.quantityOnHand) > Number(item.reorderLevel)) continue;
      const existing = await this.prisma.reminder.findFirst({
        where: {
          farmId: item.farmId,
          kind: ReminderKind.LOW_STOCK,
          entityId: item.id,
          status: { in: [ReminderStatus.PENDING, ReminderStatus.OVERDUE] },
        },
      });
      if (existing) continue;
      await this.prisma.reminder.create({
        data: {
          farmId: item.farmId,
          kind: ReminderKind.LOW_STOCK,
          status: ReminderStatus.PENDING,
          title: `Low stock: ${item.name}`,
          body: `On hand: ${item.quantityOnHand}. Reorder level: ${item.reorderLevel}.`,
          dueDate: today,
          entity: 'InventoryItem',
          entityId: item.id,
        },
      });
      lowStockCreated++;
    }

    // 3. Invoice due — 2 days before dueDate, one per invoice.
    const soon = new Date(today);
    soon.setDate(soon.getDate() + 2);
    const dueInvoices = await this.prisma.invoice.findMany({
      where: {
        status: { in: ['OPEN', 'PARTIAL'] },
        dueDate: { gte: today, lte: soon },
      },
      select: { id: true, farmId: true, number: true, dueDate: true, customer: { select: { name: true } } },
    });
    let invoiceDueCreated = 0;
    for (const inv of dueInvoices) {
      const existing = await this.prisma.reminder.findFirst({
        where: {
          farmId: inv.farmId,
          kind: ReminderKind.INVOICE_DUE,
          entityId: inv.id,
          status: { in: [ReminderStatus.PENDING, ReminderStatus.OVERDUE] },
        },
      });
      if (existing) continue;
      await this.prisma.reminder.create({
        data: {
          farmId: inv.farmId,
          kind: ReminderKind.INVOICE_DUE,
          status: ReminderStatus.PENDING,
          title: `${inv.number} due — ${inv.customer.name}`,
          dueDate: inv.dueDate,
          entity: 'Invoice',
          entityId: inv.id,
        },
      });
      invoiceDueCreated++;
    }

    return {
      overdue: overdue.count,
      lowStock: lowStockCreated,
      invoiceDue: invoiceDueCreated,
    };
  }
}
