import { Module } from '@nestjs/common';
import { AuditService } from '../common/audit.service';
import { RemindersController } from './reminders.controller';
import { RemindersService } from './reminders.service';

@Module({
  controllers: [RemindersController],
  providers: [RemindersService, AuditService],
})
export class RemindersModule {}
