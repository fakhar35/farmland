import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../common/auth.guard';
import { FarmRoleGuard } from '../common/farm-role.guard';
import { CreateSupplierDto, UpdateSupplierDto } from './suppliers.dto';
import { SuppliersService } from './suppliers.service';

@Controller('farms/:farmId/suppliers')
@UseGuards(AuthGuard, FarmRoleGuard)
export class SuppliersController {
  constructor(private suppliers: SuppliersService) {}

  @Get()
  list(@Param('farmId') farmId: string) { return this.suppliers.list(farmId); }

  @Post()
  create(@Param('farmId') farmId: string, @Body() dto: CreateSupplierDto) {
    return this.suppliers.create(farmId, dto);
  }

  @Patch(':id')
  update(@Param('farmId') farmId: string, @Param('id') id: string, @Body() dto: UpdateSupplierDto) {
    return this.suppliers.update(farmId, id, dto);
  }
}
