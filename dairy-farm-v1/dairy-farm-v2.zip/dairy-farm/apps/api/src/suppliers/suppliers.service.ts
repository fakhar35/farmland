import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateSupplierDto, UpdateSupplierDto } from './suppliers.dto';

@Injectable()
export class SuppliersService {
  constructor(private prisma: PrismaService) {}

  list(farmId: string) {
    return this.prisma.supplier.findMany({
      where: { farmId, active: true },
      orderBy: { name: 'asc' },
    });
  }

  create(farmId: string, dto: CreateSupplierDto) {
    return this.prisma.supplier.create({ data: { farmId, ...dto } });
  }

  update(farmId: string, id: string, dto: UpdateSupplierDto) {
    return this.prisma.supplier.update({ where: { id, farmId }, data: dto });
  }
}
