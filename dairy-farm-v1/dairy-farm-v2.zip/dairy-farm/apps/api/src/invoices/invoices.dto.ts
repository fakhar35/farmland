import {
  ArrayMinSize, IsArray, IsInt, IsISO8601, IsNumber, IsOptional, IsString, IsUUID, Min, MinLength, ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

export class InvoiceLineDto {
  @IsString() @MinLength(1) description: string;
  @IsNumber() @Min(0.01) quantity: number;
  @IsInt() @Min(0) unitCents: number;
  @IsInt() @Min(0) totalCents: number;
}

export class CreateInvoiceDto {
  @IsUUID() customerId: string;
  @IsISO8601() issueDate: string;
  @IsOptional() @IsISO8601() dueDate?: string;
  @IsOptional() @IsString() notes?: string;
  @IsArray() @ArrayMinSize(1) @ValidateNested({ each: true }) @Type(() => InvoiceLineDto)
  lines: InvoiceLineDto[];
}

export class InvoiceFromSalesDto {
  @IsUUID() customerId: string;
  @IsArray() @ArrayMinSize(1) @IsUUID('all', { each: true }) saleIds: string[];
  @IsOptional() @IsISO8601() issueDate?: string;
  @IsOptional() @IsISO8601() dueDate?: string;
  @IsOptional() @IsString() notes?: string;
}

export class AddPaymentDto {
  @IsISO8601() date: string;
  @IsInt() @Min(1) amountCents: number;
  @IsOptional() @IsString() method?: string;
  @IsOptional() @IsString() reference?: string;
  @IsOptional() @IsString() note?: string;
}
