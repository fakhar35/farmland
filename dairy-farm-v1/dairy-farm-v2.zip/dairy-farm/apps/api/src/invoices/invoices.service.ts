import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InvoiceStatus, PaymentDirection, Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../common/audit.service';
import { AddPaymentDto, CreateInvoiceDto, InvoiceFromSalesDto } from './invoices.dto';

// ---------------------------------------------------------------
// Invoice lifecycle
//   DRAFT   → editable, no totals yet exposed to customer
//   OPEN    → issued, awaiting payment
//   PARTIAL → some payments received, balance remains
//   PAID    → paid in full
//   VOID    → cancelled, kept for audit trail
//
// Every mutation (line add/remove, payment) recomputes subtotalCents,
// paidCents, and derives status. This keeps reports consistent without
// having to join back through lines/payments on every read.
// ---------------------------------------------------------------

type Tx = Prisma.TransactionClient;

@Injectable()
export class InvoicesService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
  ) {}

  // ---- reads ----

  list(farmId: string, status?: InvoiceStatus) {
    return this.prisma.invoice.findMany({
      where: { farmId, ...(status ? { status } : {}) },
      orderBy: [{ issueDate: 'desc' }, { createdAt: 'desc' }],
      include: {
        customer: { select: { id: true, name: true } },
        _count: { select: { lines: true } },
      },
    });
  }

  async get(farmId: string, id: string) {
    const inv = await this.prisma.invoice.findUnique({
      where: { id, farmId },
      include: {
        customer: true,
        lines: { orderBy: { createdAt: 'asc' } },
        payments: { orderBy: { date: 'asc' } },
        sales: { select: { id: true, date: true, liters: true, priceCentsPerLiter: true } },
      },
    });
    if (!inv) throw new NotFoundException('Invoice not found');
    return inv;
  }

  // ---- create ----

  async create(farmId: string, userId: string, dto: CreateInvoiceDto) {
    return this.prisma.$transaction(async (tx) => {
      const customer = await tx.customer.findUnique({
        where: { id: dto.customerId, farmId },
      });
      if (!customer) throw new BadRequestException('Customer not found');

      const number = await this.nextInvoiceNumber(tx, farmId);
      const dueDate = dto.dueDate
        ? new Date(dto.dueDate)
        : this.addDays(new Date(dto.issueDate), customer.paymentTermsDays);

      const subtotal = dto.lines.reduce((s, l) => s + l.totalCents, 0);
      const invoice = await tx.invoice.create({
        data: {
          farmId,
          customerId: dto.customerId,
          number,
          issueDate: new Date(dto.issueDate),
          dueDate,
          status: InvoiceStatus.OPEN,
          subtotalCents: subtotal,
          notes: dto.notes,
          createdById: userId,
          lines: {
            create: dto.lines.map((l) => ({
              description: l.description,
              quantity: new Prisma.Decimal(l.quantity),
              unitCents: l.unitCents,
              totalCents: l.totalCents,
            })),
          },
        },
        include: { lines: true },
      });

      await this.audit.log({
        farmId, userId, action: 'invoice.create', entity: 'Invoice', entityId: invoice.id, data: dto,
      });
      return invoice;
    });
  }

  // Bulk-invoice unpaid sales from V1/quick flow, one invoice per customer.
  async createFromSales(farmId: string, userId: string, dto: InvoiceFromSalesDto) {
    return this.prisma.$transaction(async (tx) => {
      const sales = await tx.sale.findMany({
        where: {
          id: { in: dto.saleIds },
          farmId,
          invoiceId: null,
          customerId: dto.customerId,
          paid: false,
        },
      });
      if (sales.length !== dto.saleIds.length) {
        throw new BadRequestException(
          'One or more sales are missing, already invoiced, marked paid, or belong to a different customer',
        );
      }
      if (sales.length === 0) throw new BadRequestException('No sales to invoice');

      const customer = await tx.customer.findUniqueOrThrow({
        where: { id: dto.customerId, farmId },
      });
      const number = await this.nextInvoiceNumber(tx, farmId);
      const issueDate = new Date(dto.issueDate ?? new Date().toISOString().slice(0, 10));
      const dueDate = dto.dueDate
        ? new Date(dto.dueDate)
        : this.addDays(issueDate, customer.paymentTermsDays);

      // One line per sale so the invoice reads clearly to the customer.
      const lines = sales.map((s: { id: string; date: Date; liters: unknown; priceCentsPerLiter: number }) => {
        const qty = Number(s.liters);
        const total = Math.round(qty * s.priceCentsPerLiter);
        return {
          description: `Milk delivery ${s.date.toISOString().slice(0, 10)}`,
          quantity: new Prisma.Decimal(qty),
          unitCents: s.priceCentsPerLiter,
          totalCents: total,
        };
      });
      const subtotal = lines.reduce((s: number, l: { totalCents: number }) => s + l.totalCents, 0);

      const invoice = await tx.invoice.create({
        data: {
          farmId,
          customerId: dto.customerId,
          number,
          issueDate,
          dueDate,
          status: InvoiceStatus.OPEN,
          subtotalCents: subtotal,
          notes: dto.notes,
          createdById: userId,
          lines: { create: lines },
        },
        include: { lines: true },
      });

      await tx.sale.updateMany({
        where: { id: { in: sales.map((s: { id: string }) => s.id) } },
        data: { invoiceId: invoice.id },
      });

      await this.audit.log({
        farmId, userId, action: 'invoice.createFromSales', entity: 'Invoice', entityId: invoice.id,
        data: { saleIds: dto.saleIds },
      });
      return invoice;
    });
  }

  // ---- payments ----

  async addPayment(farmId: string, userId: string, invoiceId: string, dto: AddPaymentDto) {
    return this.prisma.$transaction(async (tx) => {
      const inv = await tx.invoice.findUnique({
        where: { id: invoiceId, farmId },
      });
      if (!inv) throw new NotFoundException('Invoice not found');
      if (inv.status === InvoiceStatus.VOID) throw new BadRequestException('Invoice is void');

      const remaining = inv.subtotalCents - inv.paidCents;
      if (dto.amountCents > remaining) {
        throw new BadRequestException(
          `Payment (${dto.amountCents}) exceeds remaining balance (${remaining})`,
        );
      }

      const payment = await tx.payment.create({
        data: {
          farmId,
          direction: PaymentDirection.IN,
          date: new Date(dto.date),
          amountCents: dto.amountCents,
          method: dto.method,
          reference: dto.reference,
          invoiceId,
          note: dto.note,
          createdById: userId,
        },
      });

      const newPaid = inv.paidCents + dto.amountCents;
      const newStatus =
        newPaid >= inv.subtotalCents
          ? InvoiceStatus.PAID
          : newPaid > 0
          ? InvoiceStatus.PARTIAL
          : InvoiceStatus.OPEN;

      await tx.invoice.update({
        where: { id: inv.id },
        data: { paidCents: newPaid, status: newStatus },
      });

      // When an invoice is fully paid, mark its sales paid too so the
      // V1 legacy `paid` flag on Sale stays honest.
      if (newStatus === InvoiceStatus.PAID) {
        await tx.sale.updateMany({
          where: { invoiceId: inv.id, paid: false },
          data: { paid: true },
        });
      }

      await this.audit.log({
        farmId, userId, action: 'invoice.payment', entity: 'Payment', entityId: payment.id,
        data: { invoiceId: inv.id, ...dto },
      });
      return { payment, invoice: { ...inv, paidCents: newPaid, status: newStatus } };
    });
  }

  async voidInvoice(farmId: string, userId: string, id: string) {
    const inv = await this.prisma.invoice.update({
      where: { id, farmId },
      data: { status: InvoiceStatus.VOID },
    });
    await this.audit.log({ farmId, userId, action: 'invoice.void', entity: 'Invoice', entityId: id });
    return inv;
  }

  // ---- helpers ----

  private async nextInvoiceNumber(tx: Tx, farmId: string): Promise<string> {
    const count = await tx.invoice.count({ where: { farmId } });
    return `INV-${String(count + 1).padStart(6, '0')}`;
  }

  private addDays(d: Date, days: number): Date {
    const r = new Date(d);
    r.setDate(r.getDate() + days);
    return r;
  }
}
