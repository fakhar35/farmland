import { Module } from '@nestjs/common';
import { AuditService } from '../common/audit.service';
import { InvoicesController } from './invoices.controller';
import { InvoicesService } from './invoices.service';

@Module({
  controllers: [InvoicesController],
  providers: [InvoicesService, AuditService],
})
export class InvoicesModule {}
