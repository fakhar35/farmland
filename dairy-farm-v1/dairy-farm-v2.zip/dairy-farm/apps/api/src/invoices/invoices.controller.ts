import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { InvoiceStatus } from '@prisma/client';
import { AuthGuard, AuthedRequest } from '../common/auth.guard';
import { FarmRoleGuard, FarmRoles, FINANCE_ROLES } from '../common/farm-role.guard';
import { AddPaymentDto, CreateInvoiceDto, InvoiceFromSalesDto } from './invoices.dto';
import { InvoicesService } from './invoices.service';

@Controller('farms/:farmId/invoices')
@UseGuards(AuthGuard, FarmRoleGuard)
@FarmRoles(...FINANCE_ROLES)
export class InvoicesController {
  constructor(private invoices: InvoicesService) {}

  @Get()
  list(@Param('farmId') farmId: string, @Query('status') status?: InvoiceStatus) {
    return this.invoices.list(farmId, status);
  }

  @Get(':id')
  get(@Param('farmId') farmId: string, @Param('id') id: string) {
    return this.invoices.get(farmId, id);
  }

  @Post()
  create(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: CreateInvoiceDto) {
    return this.invoices.create(farmId, req.user!.sub, dto);
  }

  @Post('from-sales')
  createFromSales(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: InvoiceFromSalesDto) {
    return this.invoices.createFromSales(farmId, req.user!.sub, dto);
  }

  @Post(':id/payments')
  addPayment(
    @Param('farmId') farmId: string,
    @Param('id') id: string,
    @Req() req: AuthedRequest,
    @Body() dto: AddPaymentDto,
  ) {
    return this.invoices.addPayment(farmId, req.user!.sub, id, dto);
  }

  @Post(':id/void')
  voidInvoice(@Param('farmId') farmId: string, @Param('id') id: string, @Req() req: AuthedRequest) {
    return this.invoices.voidInvoice(farmId, req.user!.sub, id);
  }
}
