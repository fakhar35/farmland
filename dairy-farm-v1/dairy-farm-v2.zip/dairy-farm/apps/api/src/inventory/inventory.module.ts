import { Module } from '@nestjs/common';
import { AuditService } from '../common/audit.service';
import { InventoryController } from './inventory.controller';
import { InventoryService } from './inventory.service';

@Module({
  controllers: [InventoryController],
  providers: [InventoryService, AuditService],
  exports: [InventoryService],  // feed and health modules consume from stock
})
export class InventoryModule {}
