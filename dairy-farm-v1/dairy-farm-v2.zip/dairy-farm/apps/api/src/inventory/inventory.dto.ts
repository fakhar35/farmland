import { InventoryCategory, StockMovementType } from '@prisma/client';
import {
  IsEnum, IsInt, IsISO8601, IsNumber, IsOptional, IsString, IsUUID, Min, MinLength,
} from 'class-validator';

export class CreateItemDto {
  @IsString() @MinLength(1) name: string;
  @IsEnum(InventoryCategory) category: InventoryCategory;
  @IsOptional() @IsString() unit?: string;
  @IsOptional() @IsNumber() @Min(0) reorderLevel?: number;
}

export class PurchaseDto {
  @IsUUID() itemId: string;
  @IsISO8601() date: string;
  @IsNumber() @Min(0.001) quantity: number;
  @IsInt() @Min(0) costCents: number;
  @IsOptional() @IsUUID() supplierId?: string;
  @IsOptional() @IsString() note?: string;
}

export class ConsumeDto {
  @IsUUID() itemId: string;
  @IsISO8601() date: string;
  @IsNumber() @Min(0.001) quantity: number;
  @IsOptional() @IsEnum(StockMovementType) type?: StockMovementType;
  @IsOptional() @IsString() linkedEntity?: string;
  @IsOptional() @IsUUID() linkedEntityId?: string;
  @IsOptional() @IsString() note?: string;
}

export class AdjustDto {
  @IsUUID() itemId: string;
  @IsISO8601() date: string;
  @IsNumber() delta: number;  // signed: negative = write-down, positive = write-up
  @IsOptional() @IsString() note?: string;
}
