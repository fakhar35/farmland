import { BadRequestException, Injectable } from '@nestjs/common';
import { InventoryCategory, Prisma, StockMovementType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../common/audit.service';
import { CreateItemDto, PurchaseDto, ConsumeDto, AdjustDto } from './inventory.dto';

// ---------------------------------------------------------------
// Weighted-Average Cost (WAC) inventory
//
// The invariant every operation must preserve:
//   quantityOnHand and wacCents on InventoryItem always reflect the
//   result of applying all StockMovements in date order.
//
// Purchase: new WAC = (old_qty * old_wac + purchase_cost) / (old_qty + qty_in)
//   Cost carried on the item goes UP by exactly purchase_cost.
//
// Consumption / Waste: quantity leaves at the CURRENT wac.
//   costCents on the movement = qty_out * wac (rounded).
//   WAC does not change.
//
// Adjustment: quantity delta (+ or -) at CURRENT wac.
//   costCents on the movement = qty_delta * wac.
//   WAC does not change.
//
// All mutations happen inside a transaction so quantity and WAC can
// never desynchronize under concurrent writes.
// ---------------------------------------------------------------

const D = Prisma.Decimal;
type Tx = Prisma.TransactionClient;

@Injectable()
export class InventoryService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditService,
  ) {}

  // ---- reads ----

  listItems(farmId: string, category?: InventoryCategory) {
    return this.prisma.inventoryItem.findMany({
      where: { farmId, active: true, ...(category ? { category } : {}) },
      orderBy: [{ category: 'asc' }, { name: 'asc' }],
    });
  }

  listMovements(farmId: string, itemId?: string, limit = 50) {
    return this.prisma.stockMovement.findMany({
      where: { farmId, ...(itemId ? { itemId } : {}) },
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
      take: limit,
      include: {
        item: { select: { id: true, name: true, unit: true } },
        supplier: { select: { id: true, name: true } },
      },
    });
  }

  // ---- create item ----

  create(farmId: string, dto: CreateItemDto) {
    return this.prisma.inventoryItem.create({
      data: {
        farmId,
        name: dto.name,
        category: dto.category,
        unit: dto.unit ?? 'kg',
        reorderLevel: dto.reorderLevel != null ? new D(dto.reorderLevel) : null,
      },
    });
  }

  // ---- purchase (stock IN) ----

  async purchase(farmId: string, userId: string, dto: PurchaseDto) {
    return this.prisma.$transaction(async (tx) => {
      const item = await this.getItemForUpdate(tx, farmId, dto.itemId);
      const qtyIn = new D(dto.quantity);
      const costIn = dto.costCents;
      const oldQty = new D(item.quantityOnHand);
      const oldWac = item.wacCents;

      // new WAC in cents; guard against zero-qty division
      const newQty = oldQty.plus(qtyIn);
      const newWacCents = newQty.isZero()
        ? 0
        : Math.round(oldQty.mul(oldWac).plus(costIn).div(newQty).toNumber());

      await tx.inventoryItem.update({
        where: { id: item.id },
        data: { quantityOnHand: newQty, wacCents: newWacCents },
      });

      const movement = await tx.stockMovement.create({
        data: {
          farmId,
          itemId: item.id,
          type: StockMovementType.PURCHASE,
          date: new Date(dto.date),
          quantity: qtyIn,
          costCents: costIn,
          supplierId: dto.supplierId,
          note: dto.note,
          createdById: userId,
        },
      });

      await this.audit.log({
        farmId, userId, action: 'inventory.purchase', entity: 'StockMovement', entityId: movement.id, data: dto,
      });
      return movement;
    });
  }

  // ---- consume (stock OUT), used by feed and health flows ----

  async consume(farmId: string, userId: string, dto: ConsumeDto) {
    return this.prisma.$transaction((tx) =>
      this.consumeInTx(tx, farmId, userId, dto),
    );
  }

  // Exposed for other services (feed, treatments) to bundle consumption
  // into their own transactions and get the resulting cost back.
  async consumeInTx(
    tx: Tx,
    farmId: string,
    userId: string,
    dto: ConsumeDto,
  ): Promise<{ movementId: string; costCents: number }> {
    const item = await this.getItemForUpdate(tx, farmId, dto.itemId);
    const qtyOut = new D(dto.quantity);
    const oldQty = new D(item.quantityOnHand);
    if (qtyOut.lte(0)) throw new BadRequestException('Quantity must be positive');
    if (qtyOut.gt(oldQty)) {
      throw new BadRequestException(
        `Only ${oldQty.toString()} ${item.unit} of ${item.name} on hand`,
      );
    }
    const costCents = Math.round(qtyOut.mul(item.wacCents).toNumber());
    const newQty = oldQty.minus(qtyOut);

    await tx.inventoryItem.update({
      where: { id: item.id },
      data: { quantityOnHand: newQty },
    });

    const movement = await tx.stockMovement.create({
      data: {
        farmId,
        itemId: item.id,
        type: dto.type ?? StockMovementType.CONSUMPTION,
        date: new Date(dto.date),
        quantity: qtyOut,
        costCents,
        linkedEntity: dto.linkedEntity,
        linkedEntityId: dto.linkedEntityId,
        note: dto.note,
        createdById: userId,
      },
    });

    return { movementId: movement.id, costCents };
  }

  // ---- adjust (correction) ----

  async adjust(farmId: string, userId: string, dto: AdjustDto) {
    return this.prisma.$transaction(async (tx) => {
      const item = await this.getItemForUpdate(tx, farmId, dto.itemId);
      const delta = new D(dto.delta);
      const oldQty = new D(item.quantityOnHand);
      const newQty = oldQty.plus(delta);
      if (newQty.isNegative()) {
        throw new BadRequestException('Adjustment would make quantity negative');
      }
      const valueChange = Math.round(delta.mul(item.wacCents).toNumber());

      await tx.inventoryItem.update({
        where: { id: item.id },
        data: { quantityOnHand: newQty },
      });

      const movement = await tx.stockMovement.create({
        data: {
          farmId,
          itemId: item.id,
          type: StockMovementType.ADJUSTMENT,
          date: new Date(dto.date),
          quantity: delta,
          costCents: valueChange,
          note: dto.note,
          createdById: userId,
        },
      });

      await this.audit.log({
        farmId, userId, action: 'inventory.adjust', entity: 'StockMovement', entityId: movement.id, data: dto,
      });
      return movement;
    });
  }

  // ---- helpers ----

  // Prisma's default reads don't lock. For WAC we need a serialized view
  // of the item within the transaction — the SELECT FOR UPDATE hint.
  private async getItemForUpdate(tx: Tx, farmId: string, itemId: string) {
    const rows = await tx.$queryRaw<
      Array<{
        id: string;
        farmId: string;
        name: string;
        unit: string;
        quantityOnHand: Prisma.Decimal;
        wacCents: number;
      }>
    >(Prisma.sql`
      SELECT id, "farmId", name, unit, "quantityOnHand", "wacCents"
      FROM "InventoryItem"
      WHERE id = ${itemId}::uuid AND "farmId" = ${farmId}::uuid
      FOR UPDATE
    `);
    if (rows.length === 0) throw new BadRequestException('Inventory item not found');
    return rows[0];
  }
}
