import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { InventoryCategory, Role } from '@prisma/client';
import { AuthGuard, AuthedRequest } from '../common/auth.guard';
import { FarmRoleGuard, FarmRoles, FINANCE_ROLES } from '../common/farm-role.guard';
import { AdjustDto, ConsumeDto, CreateItemDto, PurchaseDto } from './inventory.dto';
import { InventoryService } from './inventory.service';

@Controller('farms/:farmId/inventory')
@UseGuards(AuthGuard, FarmRoleGuard)
export class InventoryController {
  constructor(private inv: InventoryService) {}

  @Get('items')
  listItems(@Param('farmId') farmId: string, @Query('category') category?: InventoryCategory) {
    return this.inv.listItems(farmId, category);
  }

  @Get('movements')
  listMovements(@Param('farmId') farmId: string, @Query('itemId') itemId?: string) {
    return this.inv.listMovements(farmId, itemId);
  }

  @Post('items')
  @FarmRoles(Role.OWNER, Role.MANAGER)
  create(@Param('farmId') farmId: string, @Body() dto: CreateItemDto) {
    return this.inv.create(farmId, dto);
  }

  @Post('purchase')
  @FarmRoles(...FINANCE_ROLES)
  purchase(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: PurchaseDto) {
    return this.inv.purchase(farmId, req.user!.sub, dto);
  }

  @Post('consume')
  consume(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: ConsumeDto) {
    return this.inv.consume(farmId, req.user!.sub, dto);
  }

  @Post('adjust')
  @FarmRoles(Role.OWNER, Role.MANAGER)
  adjust(@Param('farmId') farmId: string, @Req() req: AuthedRequest, @Body() dto: AdjustDto) {
    return this.inv.adjust(farmId, req.user!.sub, dto);
  }
}
