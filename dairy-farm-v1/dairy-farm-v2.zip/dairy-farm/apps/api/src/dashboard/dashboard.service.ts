import { Injectable } from '@nestjs/common';
import { ReminderStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

interface DayTotals {
  date: string;
  milkLiters: number;
  soldLiters: number;
  revenueCents: number;
  feedCostCents: number;
  expenseCents: number;
  profitCents: number;
}

function iso(d: Date): string {
  return d.toISOString().slice(0, 10);
}

@Injectable()
export class DashboardService {
  constructor(private prisma: PrismaService) {}

  async payload(farmId: string) {
    const today = new Date();
    const start = new Date();
    start.setDate(start.getDate() - 6);

    const [
      milk, feed, expenses, sales, groups, animals, unpaidInvoices, unpaidSales,
      reminders, withdrawalCount, lowStockCount,
    ] = await Promise.all([
      this.prisma.milkRecord.findMany({
        where: { farmId, date: { gte: start, lte: today } },
        select: { date: true, liters: true, quarantined: true },
      }),
      this.prisma.feedRecord.findMany({
        where: { farmId, date: { gte: start, lte: today } },
        select: { date: true, costCents: true },
      }),
      this.prisma.expense.findMany({
        where: { farmId, date: { gte: start, lte: today } },
        select: { date: true, amountCents: true },
      }),
      this.prisma.sale.findMany({
        where: { farmId, date: { gte: start, lte: today } },
        select: { date: true, liters: true, priceCentsPerLiter: true },
      }),
      this.prisma.herdGroup.findMany({
        where: { farmId },
        select: { type: true, headcount: true, _count: { select: { animals: true } } },
      }),
      this.prisma.animal.count({
        where: { farmId, status: { notIn: ['SOLD', 'CULLED', 'DEAD'] } },
      }),
      // V2: unpaid balance from invoices (formal customers)
      this.prisma.invoice.aggregate({
        where: { farmId, status: { in: ['OPEN', 'PARTIAL'] } },
        _sum: { subtotalCents: true, paidCents: true },
      }),
      // Legacy: unpaid walk-in sales that aren't yet in an invoice
      this.prisma.sale.findMany({
        where: { farmId, paid: false, invoiceId: null },
        select: { liters: true, priceCentsPerLiter: true },
      }),
      // Pending & overdue reminder counts by kind for the dashboard chip
      this.prisma.reminder.groupBy({
        by: ['kind', 'status'],
        where: { farmId, status: { in: [ReminderStatus.PENDING, ReminderStatus.OVERDUE] } },
        _count: true,
      }),
      // V2: how many animals are under milk withdrawal right now
      this.prisma.$queryRaw<Array<{ n: bigint }>>`
        SELECT COUNT(DISTINCT t."animalId")::bigint AS n
        FROM "Treatment" t
        WHERE t."farmId" = ${farmId}::uuid
          AND t."withdrawalDays" > 0
          AND (t.date + (t."withdrawalDays" || ' days')::interval)::date >= CURRENT_DATE
      `,
      this.prisma.reminder.count({
        where: { farmId, kind: 'LOW_STOCK', status: { in: [ReminderStatus.PENDING, ReminderStatus.OVERDUE] } },
      }),
    ]);

    // 7-day series
    const series: DayTotals[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = iso(d);
      const dayMilk = milk.filter((m) => iso(m.date) === key).reduce((s, m) => s + Number(m.liters), 0);
      const daySales = sales.filter((x) => iso(x.date) === key);
      const soldLiters = daySales.reduce((s, x) => s + Number(x.liters), 0);
      const revenueCents = daySales.reduce((s, x) => s + Math.round(Number(x.liters) * x.priceCentsPerLiter), 0);
      const feedCostCents = feed.filter((f) => iso(f.date) === key).reduce((s, f) => s + f.costCents, 0);
      const expenseCents = expenses.filter((e) => iso(e.date) === key).reduce((s, e) => s + e.amountCents, 0);
      series.push({
        date: key,
        milkLiters: dayMilk,
        soldLiters,
        revenueCents,
        feedCostCents,
        expenseCents,
        profitCents: revenueCents - feedCostCents - expenseCents,
      });
    }

    const groupHeadcount = groups.reduce((s, g) => s + g.headcount, 0);
    const totalAnimals = animals > 0 ? animals : groupHeadcount;
    const milkingCount = groups
      .filter((g) => g.type === 'MILKING')
      .reduce((s, g) => s + (g._count.animals > 0 ? g._count.animals : g.headcount), 0);

    const unpaidInvoiceCents =
      (unpaidInvoices._sum.subtotalCents ?? 0) - (unpaidInvoices._sum.paidCents ?? 0);
    const unpaidWalkInCents = unpaidSales.reduce(
      (s, x) => s + Math.round(Number(x.liters) * x.priceCentsPerLiter),
      0,
    );
    const unpaidCents = Math.max(0, unpaidInvoiceCents) + unpaidWalkInCents;

    // Milk under quarantine — informational badge on the ledger.
    const quarantinedTodayLiters = milk
      .filter((m) => iso(m.date) === iso(today) && m.quarantined)
      .reduce((s, m) => s + Number(m.liters), 0);

    return {
      today: series[series.length - 1],
      series7d: series,
      totalAnimals,
      milkingCount,
      unpaidCents,
      // V2 additions
      quarantinedTodayLiters,
      animalsUnderWithdrawal: Number(withdrawalCount[0]?.n ?? 0),
      remindersByKind: reminders,
      lowStockCount,
    };
  }
}
