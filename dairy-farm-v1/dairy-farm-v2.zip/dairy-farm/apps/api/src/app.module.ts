import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { FarmsModule } from './farms/farms.module';
import { GroupsModule } from './groups/groups.module';
import { AnimalsModule } from './animals/animals.module';
import { RecordsModule } from './records/records.module';
import { DashboardModule } from './dashboard/dashboard.module';
// V2 additions
import { CustomersModule } from './customers/customers.module';
import { SuppliersModule } from './suppliers/suppliers.module';
import { InventoryModule } from './inventory/inventory.module';
import { InvoicesModule } from './invoices/invoices.module';
import { HealthModule } from './health/health.module';
import { BreedingModule } from './breeding/breeding.module';
import { RemindersModule } from './reminders/reminders.module';

@Module({
  imports: [
    PrismaModule,
    AuthModule,
    FarmsModule,
    GroupsModule,
    AnimalsModule,
    RecordsModule,
    DashboardModule,
    // V2
    CustomersModule,
    SuppliersModule,
    InventoryModule,
    InvoicesModule,
    HealthModule,
    BreedingModule,
    RemindersModule,
  ],
})
export class AppModule {}
