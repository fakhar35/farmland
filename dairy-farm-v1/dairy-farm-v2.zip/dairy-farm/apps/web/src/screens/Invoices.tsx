import { useCallback, useEffect, useState } from 'react';
import { get, post } from '../api';
import { Customer, Farm, InvoiceListItem } from '../types';

const money = (cents: number, sym: string) =>
  `${sym} ${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;

interface UninvoicedSale { id: string; date: string; liters: string; priceCentsPerLiter: number; }

export default function Invoices({ farm, notify }: { farm: Farm; notify: (m: string) => void }) {
  const [invoices, setInvoices] = useState<InvoiceListItem[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [wizardCustomerId, setWizardCustomerId] = useState('');
  const [uninvoiced, setUninvoiced] = useState<UninvoicedSale[]>([]);
  const [selectedSales, setSelectedSales] = useState<Set<string>>(new Set());
  const [payingId, setPayingId] = useState<string | null>(null);
  const [payAmount, setPayAmount] = useState('');

  const load = useCallback(() => {
    Promise.all([
      get<InvoiceListItem[]>(`/farms/${farm.id}/invoices`),
      get<Customer[]>(`/farms/${farm.id}/customers`),
    ]).then(([i, c]) => { setInvoices(i); setCustomers(c); })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load'));
  }, [farm.id]);
  useEffect(load, [load]);

  const loadUninvoiced = async (customerId: string) => {
    setWizardCustomerId(customerId);
    setSelectedSales(new Set());
    if (!customerId) { setUninvoiced([]); return; }
    const sales = await get<UninvoicedSale[]>(`/farms/${farm.id}/customers/${customerId}/uninvoiced-sales`);
    setUninvoiced(sales);
  };

  const toggleSale = (id: string) => {
    const next = new Set(selectedSales);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelectedSales(next);
  };

  const createFromSales = async () => {
    if (!wizardCustomerId || selectedSales.size === 0) return;
    await post(`/farms/${farm.id}/invoices/from-sales`, {
      customerId: wizardCustomerId,
      saleIds: Array.from(selectedSales),
      issueDate: new Date().toISOString().slice(0, 10),
    });
    setWizardCustomerId(''); setUninvoiced([]); setSelectedSales(new Set());
    notify('Invoice created');
    load();
  };

  const pay = async (invoiceId: string) => {
    const amountCents = Math.round(parseFloat(payAmount) * 100);
    if (!amountCents) return;
    await post(`/farms/${farm.id}/invoices/${invoiceId}/payments`, {
      date: new Date().toISOString().slice(0, 10),
      amountCents,
      method: 'cash',
    });
    setPayingId(null); setPayAmount('');
    notify('Payment recorded');
    load();
  };

  const statusTag = (s: string) => {
    const cls = s === 'PAID' ? ' green' : s === 'OPEN' || s === 'PARTIAL' ? '' : ' red';
    return <span className={'tag' + cls}>{s.toLowerCase()}</span>;
  };

  const previewTotal = uninvoiced
    .filter((s) => selectedSales.has(s.id))
    .reduce((sum, s) => sum + Math.round(parseFloat(s.liters) * s.priceCentsPerLiter), 0);

  return (
    <>
      {error && <div className="error">{error}</div>}

      <div className="card">
        <h3 style={{ fontSize: 16, marginBottom: 10 }}>Invoice unpaid sales</h3>
        <p style={{ fontSize: 13, color: 'var(--ink-soft)', marginBottom: 10 }}>
          Pick a customer, choose which sales to bill, and generate one invoice covering all of them.
        </p>
        <div className="field">
          <label style={lbl}>Customer</label>
          <select value={wizardCustomerId} onChange={(e) => loadUninvoiced(e.target.value)}>
            <option value="">— pick a customer —</option>
            {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        {wizardCustomerId && (
          uninvoiced.length === 0 ? (
            <div className="empty">No unpaid, uninvoiced sales for this customer.</div>
          ) : (
            <>
              <table className="tbl">
                <thead><tr><th></th><th>Date</th><th>Liters</th><th>Price / L</th><th style={{ textAlign: 'right' }}>Total</th></tr></thead>
                <tbody>
                  {uninvoiced.map((s) => {
                    const t = Math.round(parseFloat(s.liters) * s.priceCentsPerLiter);
                    return (
                      <tr key={s.id}>
                        <td><input type="checkbox" checked={selectedSales.has(s.id)} onChange={() => toggleSale(s.id)} /></td>
                        <td>{s.date.slice(0, 10)}</td>
                        <td>{parseFloat(s.liters).toFixed(1)} L</td>
                        <td>{farm.currencySymbol} {(s.priceCentsPerLiter / 100).toFixed(2)}</td>
                        <td style={{ textAlign: 'right' }}>{money(t, farm.currencySymbol)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
                <div style={{ fontSize: 14 }}>
                  {selectedSales.size} selected · <b>{money(previewTotal, farm.currencySymbol)}</b>
                </div>
                <button className="btn" disabled={selectedSales.size === 0} onClick={createFromSales}>
                  Create invoice
                </button>
              </div>
            </>
          )
        )}
      </div>

      <div className="card">
        <h3 style={{ fontSize: 16, marginBottom: 10 }}>All invoices</h3>
        {invoices.length === 0 ? (
          <div className="empty">No invoices yet.</div>
        ) : (
          <table className="tbl">
            <thead>
              <tr><th>#</th><th>Customer</th><th>Issued</th><th>Due</th><th>Total</th><th>Paid</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {invoices.map((inv) => {
                const remaining = inv.subtotalCents - inv.paidCents;
                return (
                  <tr key={inv.id}>
                    <td style={{ fontWeight: 700 }}>{inv.number}</td>
                    <td>{inv.customer.name}</td>
                    <td>{inv.issueDate.slice(0, 10)}</td>
                    <td>{inv.dueDate.slice(0, 10)}</td>
                    <td>{money(inv.subtotalCents, farm.currencySymbol)}</td>
                    <td>{money(inv.paidCents, farm.currencySymbol)}</td>
                    <td>{statusTag(inv.status)}</td>
                    <td>
                      {(inv.status === 'OPEN' || inv.status === 'PARTIAL') && (
                        payingId === inv.id ? (
                          <div style={{ display: 'flex', gap: 4 }}>
                            <input
                              type="number" step="0.01" style={{ width: 90 }}
                              value={payAmount} onChange={(e) => setPayAmount(e.target.value)}
                              placeholder={`≤ ${(remaining / 100).toFixed(2)}`}
                              autoFocus onKeyDown={(e) => e.key === 'Enter' && pay(inv.id)}
                            />
                            <button className="btn small" onClick={() => pay(inv.id)}>Pay</button>
                          </div>
                        ) : (
                          <button className="btn ghost small" onClick={() => { setPayingId(inv.id); setPayAmount((remaining / 100).toFixed(2)); }}>
                            Record payment
                          </button>
                        )
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

const lbl: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-soft)', marginBottom: 5 };
