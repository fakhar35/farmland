import { useCallback, useEffect, useState } from 'react';
import { get, patch, post } from '../api';
import { Customer, Farm } from '../types';

const money = (cents: number, sym: string) =>
  `${sym} ${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;

export default function Customers({ farm, notify }: { farm: Farm; notify: (m: string) => void }) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [price, setPrice] = useState('');
  const [terms, setTerms] = useState('14');

  const load = useCallback(() => {
    get<Customer[]>(`/farms/${farm.id}/customers?withBalances=1`)
      .then(setCustomers)
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load'));
  }, [farm.id]);
  useEffect(load, [load]);

  const add = async () => {
    if (!name.trim()) return;
    await post(`/farms/${farm.id}/customers`, {
      name: name.trim(),
      phone: phone || undefined,
      priceCentsPerLiter: price ? Math.round(parseFloat(price) * 100) : undefined,
      paymentTermsDays: Number(terms) || 14,
    });
    setName(''); setPhone(''); setPrice(''); setTerms('14'); setShowAdd(false);
    notify('Customer added');
    load();
  };

  return (
    <>
      {error && <div className="error">{error}</div>}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <h3 style={{ fontSize: 16 }}>Customers</h3>
          <button className="btn small" onClick={() => setShowAdd(!showAdd)}>
            {showAdd ? 'Cancel' : '+ Add customer'}
          </button>
        </div>
        {showAdd && (
          <div style={{ background: 'var(--field)', padding: 12, borderRadius: 10, marginBottom: 12 }}>
            <div className="row field">
              <div>
                <label style={lbl}>Name</label>
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Valley Dairy Co-op" />
              </div>
              <div>
                <label style={lbl}>Phone</label>
                <input value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
            </div>
            <div className="row field">
              <div>
                <label style={lbl}>Agreed price / L ({farm.currencySymbol})</label>
                <input type="number" step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} />
              </div>
              <div>
                <label style={lbl}>Payment terms (days)</label>
                <input type="number" value={terms} onChange={(e) => setTerms(e.target.value)} />
              </div>
            </div>
            <button className="btn" onClick={add}>Save customer</button>
          </div>
        )}
        {customers.length === 0 ? (
          <div className="empty">No customers yet. Add one above.</div>
        ) : (
          <table className="tbl">
            <thead>
              <tr><th>Name</th><th>Phone</th><th>Price / L</th><th>Terms</th><th>Outstanding</th></tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.id}>
                  <td style={{ fontWeight: 700 }}>{c.name}</td>
                  <td>{c.phone ?? '—'}</td>
                  <td>{c.priceCentsPerLiter ? `${farm.currencySymbol} ${(c.priceCentsPerLiter / 100).toFixed(2)}` : '—'}</td>
                  <td>{c.paymentTermsDays}d</td>
                  <td style={{ color: (c.outstandingCents ?? 0) > 0 ? 'var(--alert)' : 'inherit', fontWeight: 700 }}>
                    {money(c.outstandingCents ?? 0, farm.currencySymbol)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

const lbl: React.CSSProperties = {
  display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-soft)', marginBottom: 5,
};
