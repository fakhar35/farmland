import { useCallback, useEffect, useState } from 'react';
import { get, post } from '../api';
import { Farm, InventoryCategory, InventoryItem, Supplier } from '../types';

const money = (cents: number, sym: string) =>
  `${sym} ${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 2 })}`;

const CATS: [InventoryCategory, string][] = [
  ['FEED', 'Feed'], ['MEDICINE', 'Medicine'], ['EQUIPMENT', 'Equipment'],
  ['CONSUMABLE', 'Consumable'], ['OTHER', 'Other'],
];

export default function Inventory({ farm, notify }: { farm: Farm; notify: (m: string) => void }) {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<InventoryCategory>('FEED');
  const [unit, setUnit] = useState('kg');
  const [reorder, setReorder] = useState('');
  const [purchase, setPurchase] = useState<{ itemId: string; qty: string; cost: string; supplierId: string } | null>(null);
  const [newSupplierName, setNewSupplierName] = useState('');

  const load = useCallback(() => {
    Promise.all([
      get<InventoryItem[]>(`/farms/${farm.id}/inventory/items`),
      get<Supplier[]>(`/farms/${farm.id}/suppliers`),
    ]).then(([i, s]) => { setItems(i); setSuppliers(s); })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load'));
  }, [farm.id]);
  useEffect(load, [load]);

  const addItem = async () => {
    if (!name.trim()) return;
    await post(`/farms/${farm.id}/inventory/items`, {
      name: name.trim(),
      category,
      unit,
      reorderLevel: reorder ? parseFloat(reorder) : undefined,
    });
    setName(''); setUnit('kg'); setReorder(''); setShowAdd(false);
    notify('Item added');
    load();
  };

  const doPurchase = async () => {
    if (!purchase) return;
    const qty = parseFloat(purchase.qty);
    const cost = Math.round(parseFloat(purchase.cost) * 100);
    if (!qty || !cost) return;
    if (purchase.supplierId === '__new__') return; // must finish adding first
    await post(`/farms/${farm.id}/inventory/purchase`, {
      itemId: purchase.itemId,
      date: new Date().toISOString().slice(0, 10),
      quantity: qty,
      costCents: cost,
      supplierId: purchase.supplierId || undefined,
    });
    setPurchase(null);
    notify('Purchase recorded');
    load();
  };

  return (
    <>
      {error && <div className="error">{error}</div>}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
          <h3 style={{ fontSize: 16 }}>Inventory</h3>
          <button className="btn small" onClick={() => setShowAdd(!showAdd)}>
            {showAdd ? 'Cancel' : '+ Add item'}
          </button>
        </div>
        {showAdd && (
          <div style={{ background: 'var(--field)', padding: 12, borderRadius: 10, marginBottom: 12 }}>
            <div className="row field">
              <div><label style={lbl}>Item name</label><input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Dairy pellets" /></div>
              <div><label style={lbl}>Category</label>
                <select value={category} onChange={(e) => setCategory(e.target.value as InventoryCategory)}>
                  {CATS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                </select>
              </div>
            </div>
            <div className="row field">
              <div><label style={lbl}>Unit</label><input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="kg, L, dose" /></div>
              <div><label style={lbl}>Reorder level (optional)</label><input type="number" value={reorder} onChange={(e) => setReorder(e.target.value)} /></div>
            </div>
            <button className="btn" onClick={addItem}>Save item</button>
          </div>
        )}
        {items.length === 0 ? (
          <div className="empty">No items yet.</div>
        ) : (
          <table className="tbl">
            <thead><tr><th>Item</th><th>On hand</th><th>Avg cost</th><th>Value</th><th></th></tr></thead>
            <tbody>
              {items.map((it) => {
                const qty = parseFloat(it.quantityOnHand);
                const low = it.reorderLevel && qty <= parseFloat(it.reorderLevel);
                const value = qty * it.wacCents;
                return (
                  <tr key={it.id}>
                    <td>
                      <div style={{ fontWeight: 700 }}>{it.name}</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-soft)' }}>{it.category.toLowerCase()}</div>
                    </td>
                    <td>
                      {qty.toLocaleString(undefined, { maximumFractionDigits: 2 })} {it.unit}
                      {low && <span className="tag red" style={{ marginLeft: 6 }}>low</span>}
                    </td>
                    <td>{money(it.wacCents, farm.currencySymbol)} / {it.unit}</td>
                    <td style={{ fontWeight: 700 }}>{money(value, farm.currencySymbol)}</td>
                    <td>
                      <button className="btn ghost small" onClick={() =>
                        setPurchase({ itemId: it.id, qty: '', cost: '', supplierId: '' })
                      }>Purchase</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {purchase && (
        <div className="card" style={{ borderColor: 'var(--pasture)' }}>
          <h3 style={{ fontSize: 15, marginBottom: 10 }}>Record purchase</h3>
          <div className="row field">
            <div><label style={lbl}>Quantity</label><input type="number" value={purchase.qty} onChange={(e) => setPurchase({ ...purchase, qty: e.target.value })} /></div>
            <div><label style={lbl}>Total cost ({farm.currencySymbol})</label><input type="number" step="0.01" value={purchase.cost} onChange={(e) => setPurchase({ ...purchase, cost: e.target.value })} /></div>
          </div>
          <div className="field">
            <label style={lbl}>Supplier</label>
            <select value={purchase.supplierId} onChange={(e) => setPurchase({ ...purchase, supplierId: e.target.value })}>
              <option value="">— none —</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              <option value="__new__">+ Add new supplier…</option>
            </select>
            {purchase.supplierId === '__new__' && (
              <div style={{ marginTop: 8, display: 'flex', gap: 6 }}>
                <input
                  placeholder="Supplier name"
                  value={newSupplierName}
                  onChange={(e) => setNewSupplierName(e.target.value)}
                  style={{ flex: 1 }}
                />
                <button
                  className="btn small"
                  onClick={async () => {
                    if (!newSupplierName.trim()) return;
                    try {
                      const created = await post<Supplier>(`/farms/${farm.id}/suppliers`, { name: newSupplierName.trim() });
                      setSuppliers([...suppliers, created]);
                      setPurchase({ ...purchase, supplierId: created.id });
                      setNewSupplierName('');
                      notify('Supplier added');
                    } catch (e) {
                      setError(e instanceof Error ? e.message : 'Could not add supplier');
                    }
                  }}
                >Add</button>
              </div>
            )}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button
              className="btn"
              onClick={doPurchase}
              disabled={purchase.supplierId === '__new__'}
            >
              Save purchase
            </button>
            <button className="btn ghost" onClick={() => setPurchase(null)}>Cancel</button>
          </div>
        </div>
      )}
    </>
  );
}

const lbl: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-soft)', marginBottom: 5 };
