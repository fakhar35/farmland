import { useCallback, useEffect, useState } from 'react';
import { get, post } from '../api';
import { Farm, Reminder } from '../types';

const KIND_LABELS: Record<string, string> = {
  VACCINATION: 'Vaccination', TREATMENT_FOLLOWUP: 'Treatment follow-up',
  BREEDING_CHECK: 'Pregnancy check', CALVING_DUE: 'Calving due',
  INVOICE_DUE: 'Invoice due', LOW_STOCK: 'Low stock', CUSTOM: 'Custom',
};

export default function Reminders({ farm, notify }: { farm: Farm; notify: (m: string) => void }) {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    get<Reminder[]>(`/farms/${farm.id}/reminders?windowDays=30`)
      .then(setReminders)
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load'));
  }, [farm.id]);
  useEffect(load, [load]);

  const done = async (id: string) => {
    await post(`/farms/${farm.id}/reminders/${id}/done`, {});
    notify('Marked done');
    load();
  };
  const dismiss = async (id: string) => {
    await post(`/farms/${farm.id}/reminders/${id}/dismiss`, {});
    load();
  };
  const runSweep = async () => {
    const r = await post<{ overdue: number; lowStock: number; invoiceDue: number }>(`/farms/${farm.id}/reminders/sweep`, {});
    notify(`Swept: ${r.overdue} overdue · ${r.lowStock} low stock · ${r.invoiceDue} invoice due`);
    load();
  };

  const overdue = reminders.filter((r) => r.status === 'OVERDUE');
  const pending = reminders.filter((r) => r.status === 'PENDING');

  return (
    <>
      {error && <div className="error">{error}</div>}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <div>
          <b style={{ fontSize: 16 }}>Reminders</b>
          <div style={{ fontSize: 12, color: 'var(--ink-soft)' }}>
            {overdue.length} overdue · {pending.length} coming up
          </div>
        </div>
        <button className="btn ghost small" onClick={runSweep}>Run sweep now</button>
      </div>

      {overdue.length > 0 && (
        <div className="card" style={{ borderColor: 'var(--alert)' }}>
          <h3 style={{ fontSize: 15, marginBottom: 10, color: 'var(--alert)' }}>Overdue</h3>
          <ReminderList reminders={overdue} onDone={done} onDismiss={dismiss} />
        </div>
      )}

      <div className="card">
        <h3 style={{ fontSize: 15, marginBottom: 10 }}>Coming up</h3>
        {pending.length === 0 ? (
          <div className="empty">Nothing on the horizon. 🌾</div>
        ) : (
          <ReminderList reminders={pending} onDone={done} onDismiss={dismiss} />
        )}
      </div>
    </>
  );
}

function ReminderList({ reminders, onDone, onDismiss }: { reminders: Reminder[]; onDone: (id: string) => void; onDismiss: (id: string) => void }) {
  return (
    <table className="tbl">
      <thead><tr><th>Kind</th><th>Title</th><th>Due</th><th></th></tr></thead>
      <tbody>
        {reminders.map((r) => (
          <tr key={r.id}>
            <td><span className="tag">{KIND_LABELS[r.kind] ?? r.kind}</span></td>
            <td>
              <div style={{ fontWeight: 700 }}>{r.title}</div>
              {r.body && <div style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{r.body}</div>}
            </td>
            <td>{r.dueDate.slice(0, 10)}</td>
            <td style={{ whiteSpace: 'nowrap' }}>
              <button className="btn ghost small" onClick={() => onDone(r.id)}>Done</button>{' '}
              <button className="btn ghost small" onClick={() => onDismiss(r.id)}>Dismiss</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
