import { useCallback, useEffect, useState } from 'react';
import { get, post } from '../api';
import { Animal, BreedingEvent, BreedingEventKind, Farm } from '../types';

// The event kinds shown in the picker. Order matters — most-common first.
const KINDS: [BreedingEventKind, string, string][] = [
  ['HEAT', 'Heat detected', 'Cow in estrus / ready for insemination'],
  ['INSEMINATION', 'Insemination', 'Auto-creates preg-check (30d) and calving-due (283d) reminders'],
  ['PREGNANCY_CHECK', 'Pregnancy check', 'Confirm or rule out pregnancy'],
  ['CALVING', 'Calving', 'Record the birth outcome'],
  ['ABORTION', 'Abortion', 'Failed pregnancy'],
  ['DRY_OFF', 'Dry-off', 'Stop milking in preparation for calving'],
];

const today = () => new Date().toISOString().slice(0, 10);
const addDays = (iso: string, d: number) => {
  const dt = new Date(iso);
  dt.setDate(dt.getDate() + d);
  return dt.toISOString().slice(0, 10);
};

export default function Breeding({ farm, notify }: { farm: Farm; notify: (m: string) => void }) {
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [events, setEvents] = useState<BreedingEvent[]>([]);
  const [filterAnimalId, setFilterAnimalId] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const load = useCallback(() => {
    Promise.all([
      get<Animal[]>(`/farms/${farm.id}/animals`).catch(() => []),
      get<BreedingEvent[]>(`/farms/${farm.id}/breeding${filterAnimalId ? `?animalId=${filterAnimalId}` : ''}`).catch(() => []),
    ]).then(([a, e]) => { setAnimals(a); setEvents(e); })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load'));
  }, [farm.id, filterAnimalId]);
  useEffect(load, [load]);

  if (farm.mode === 'HERD') {
    return (
      <div className="card">
        <h3 style={{ fontSize: 16 }}>Breeding records</h3>
        <div className="empty">
          Breeding tracking needs per-animal records.<br />
          Switch to Hybrid or Individual mode in Settings to use this feature.
        </div>
      </div>
    );
  }
  if (animals.length === 0) {
    return (
      <div className="card">
        <h3 style={{ fontSize: 16 }}>Breeding records</h3>
        <div className="empty">Add animals in the Herd tab first, then log breeding events here.</div>
      </div>
    );
  }

  return (
    <>
      {error && <div className="error">{error}</div>}

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <h3 style={{ fontSize: 16, margin: 0 }}>Breeding events</h3>
          <button className="btn small" onClick={() => setShowForm(!showForm)}>
            {showForm ? 'Cancel' : '+ Log event'}
          </button>
        </div>

        {showForm && (
          <BreedingForm
            farm={farm}
            animals={animals}
            onSaved={() => {
              notify('Breeding event logged');
              setShowForm(false);
              load();
            }}
          />
        )}

        <div className="field" style={{ marginTop: showForm ? 16 : 0 }}>
          <label>Filter by animal</label>
          <select value={filterAnimalId} onChange={(e) => setFilterAnimalId(e.target.value)}>
            <option value="">— all animals —</option>
            {animals.map((a) => (
              <option key={a.id} value={a.id}>
                {a.tag}{a.name ? ` (${a.name})` : ''}
              </option>
            ))}
          </select>
        </div>

        {events.length === 0 ? (
          <div className="empty">No breeding events logged{filterAnimalId ? ' for this animal' : ''}.</div>
        ) : (
          <table className="tbl">
            <thead>
              <tr><th>Date</th><th>Animal</th><th>Event</th><th>Details</th><th>Next due</th></tr>
            </thead>
            <tbody>
              {events.map((ev) => {
                const kindLabel = KINDS.find((k) => k[0] === ev.kind)?.[1] ?? ev.kind;
                const details = [
                  ev.outcome && `outcome: ${ev.outcome}`,
                  ev.bullTag && `bull: ${ev.bullTag}`,
                  ev.notes,
                ].filter(Boolean).join(' · ');
                return (
                  <tr key={ev.id}>
                    <td>{ev.date.slice(0, 10)}</td>
                    <td>{ev.animal.tag}{ev.animal.name ? ` (${ev.animal.name})` : ''}</td>
                    <td>
                      <span className={'tag' + (ev.kind === 'CALVING' ? ' green' : ev.kind === 'ABORTION' ? ' red' : '')}>
                        {kindLabel}
                      </span>
                    </td>
                    <td style={{ fontSize: 13, color: 'var(--ink-soft)' }}>{details || '—'}</td>
                    <td>{ev.nextDueDate ? ev.nextDueDate.slice(0, 10) : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

function BreedingForm({
  farm,
  animals,
  onSaved,
}: {
  farm: Farm;
  animals: Animal[];
  onSaved: () => void;
}) {
  const [kind, setKind] = useState<BreedingEventKind>('HEAT');
  const [animalId, setAnimalId] = useState(animals[0]?.id ?? '');
  const [date, setDate] = useState(today());
  // For preg-check/calving/abortion — free-form outcome
  const [outcome, setOutcome] = useState('');
  const [bullTag, setBullTag] = useState('');
  const [notes, setNotes] = useState('');
  const [nextDueDate, setNextDueDate] = useState(''); // optional override
  const [error, setError] = useState<string | null>(null);

  // Show the "outcome" field only for kinds where it makes sense
  const showOutcome = kind === 'PREGNANCY_CHECK' || kind === 'CALVING' || kind === 'ABORTION';
  const showBull = kind === 'INSEMINATION';
  const isInsemination = kind === 'INSEMINATION';

  // Hint about auto-created reminders for insemination
  const autoReminders = isInsemination ? (
    <div style={{ fontSize: 12, color: 'var(--ink-soft)', marginTop: 6 }}>
      Saving this will auto-create reminders:
      <b> pregnancy check {addDays(date, 30)}</b>,
      <b> expected calving {addDays(date, 283)}</b>
    </div>
  ) : null;

  const submit = async () => {
    if (!animalId) return;
    setError(null);
    try {
      await post(`/farms/${farm.id}/breeding`, {
        animalId,
        kind,
        date,
        nextDueDate: nextDueDate || undefined,
        outcome: showOutcome ? (outcome || undefined) : undefined,
        bullTag: showBull ? (bullTag || undefined) : undefined,
        notes: notes || undefined,
      });
      onSaved();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save');
    }
  };

  return (
    <div style={{ background: 'var(--field)', padding: 12, borderRadius: 10, marginBottom: 12 }}>
      {error && <div className="error" style={{ marginBottom: 8 }}>{error}</div>}
      <div className="field">
        <label style={lbl}>Event type</label>
        <select value={kind} onChange={(e) => setKind(e.target.value as BreedingEventKind)}>
          {KINDS.map(([k, label]) => (
            <option key={k} value={k}>{label}</option>
          ))}
        </select>
        <div style={{ fontSize: 12, color: 'var(--ink-soft)', marginTop: 4 }}>
          {KINDS.find((k) => k[0] === kind)?.[2]}
        </div>
      </div>

      <div className="row field">
        <div>
          <label style={lbl}>Animal</label>
          <select value={animalId} onChange={(e) => setAnimalId(e.target.value)}>
            {animals.map((a) => (
              <option key={a.id} value={a.id}>
                {a.tag}{a.name ? ` (${a.name})` : ''}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label style={lbl}>Date</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
      </div>

      {showBull && (
        <div className="field">
          <label style={lbl}>Bull / semen tag (optional)</label>
          <input value={bullTag} onChange={(e) => setBullTag(e.target.value)} placeholder="e.g. Holstein-A47" />
        </div>
      )}

      {showOutcome && (
        <div className="field">
          <label style={lbl}>
            {kind === 'PREGNANCY_CHECK' ? 'Result' : kind === 'CALVING' ? 'Calf sex / status' : 'Notes'}
          </label>
          <input
            value={outcome}
            onChange={(e) => setOutcome(e.target.value)}
            placeholder={
              kind === 'PREGNANCY_CHECK' ? 'e.g. Confirmed pregnant' :
              kind === 'CALVING' ? 'e.g. Female, healthy' :
              'e.g. ~2 months in'
            }
          />
        </div>
      )}

      {!isInsemination && (
        <div className="field">
          <label style={lbl}>Follow-up date (optional)</label>
          <input type="date" value={nextDueDate} onChange={(e) => setNextDueDate(e.target.value)} />
        </div>
      )}

      <div className="field">
        <label style={lbl}>Notes (optional)</label>
        <input value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>

      {autoReminders}

      <button className="btn" onClick={submit} style={{ marginTop: 10 }}>Save event</button>
    </div>
  );
}

const lbl: React.CSSProperties = {
  display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-soft)', marginBottom: 5,
};
