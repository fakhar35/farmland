import { useCallback, useEffect, useState } from 'react';
import { get, post } from '../api';
import { Animal, Farm, InventoryItem, Treatment, Vaccination } from '../types';

export default function Health({ farm, notify }: { farm: Farm; notify: (m: string) => void }) {
  const [tab, setTab] = useState<'vax' | 'treat'>('vax');
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [medicines, setMedicines] = useState<InventoryItem[]>([]);
  const [vax, setVax] = useState<Vaccination[]>([]);
  const [treatments, setTreatments] = useState<Treatment[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    Promise.all([
      get<Animal[]>(`/farms/${farm.id}/animals`).catch(() => []),
      get<InventoryItem[]>(`/farms/${farm.id}/inventory/items?category=MEDICINE`).catch(() => []),
      get<Vaccination[]>(`/farms/${farm.id}/health/vaccinations`),
      get<Treatment[]>(`/farms/${farm.id}/health/treatments`),
    ]).then(([a, m, v, t]) => { setAnimals(a); setMedicines(m); setVax(v); setTreatments(t); })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load'));
  }, [farm.id]);
  useEffect(load, [load]);

  if (farm.mode === 'HERD') {
    return (
      <div className="card">
        <h3 style={{ fontSize: 16 }}>Health tracking</h3>
        <div className="empty">
          Individual health records need per-animal tracking.<br />
          Switch to Hybrid or Individual mode in Settings to use this feature.
        </div>
      </div>
    );
  }
  if (animals.length === 0) {
    return (
      <div className="card">
        <h3 style={{ fontSize: 16 }}>Health tracking</h3>
        <div className="empty">Add animals in the Herd tab first, then come back to log health events.</div>
      </div>
    );
  }

  return (
    <>
      {error && <div className="error">{error}</div>}
      <div className="pillrow">
        <button className={'pill' + (tab === 'vax' ? ' on' : '')} onClick={() => setTab('vax')}>Vaccinations</button>
        <button className={'pill' + (tab === 'treat' ? ' on' : '')} onClick={() => setTab('treat')}>Treatments</button>
      </div>

      {tab === 'vax' && (
        <>
          <VaxForm animals={animals} medicines={medicines} onSaved={() => { notify('Vaccination recorded'); load(); }} farm={farm} />
          <div className="card">
            <h3 style={{ fontSize: 15, marginBottom: 10 }}>Recent vaccinations</h3>
            {vax.length === 0 ? <div className="empty">None yet.</div> : (
              <table className="tbl">
                <thead><tr><th>Animal</th><th>Vaccine</th><th>Date</th><th>Next due</th></tr></thead>
                <tbody>
                  {vax.map((v) => (
                    <tr key={v.id}>
                      <td style={{ fontWeight: 700 }}>{v.animal.tag}</td>
                      <td>{v.vaccine}</td>
                      <td>{v.date.slice(0, 10)}</td>
                      <td>{v.nextDueDate ? v.nextDueDate.slice(0, 10) : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      {tab === 'treat' && (
        <>
          <TreatmentForm animals={animals} medicines={medicines} onSaved={() => { notify('Treatment recorded'); load(); }} farm={farm} />
          <div className="card">
            <h3 style={{ fontSize: 15, marginBottom: 10 }}>Recent treatments</h3>
            {treatments.length === 0 ? <div className="empty">None yet.</div> : (
              <table className="tbl">
                <thead><tr><th>Animal</th><th>Condition</th><th>Medicine</th><th>Date</th><th>Withdrawal</th><th></th></tr></thead>
                <tbody>
                  {treatments.map((t) => (
                    <tr key={t.id}>
                      <td style={{ fontWeight: 700 }}>{t.animal.tag}</td>
                      <td>{t.condition}</td>
                      <td>{t.medicine}</td>
                      <td>{t.date.slice(0, 10)}</td>
                      <td>{t.withdrawalDays ? `${t.withdrawalDays} d` : '—'}</td>
                      <td>{t.resolved ? <span className="tag green">resolved</span> : <span className="tag">active</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}
    </>
  );
}

function VaxForm({ animals, medicines, onSaved, farm }: { animals: Animal[]; medicines: InventoryItem[]; onSaved: () => void; farm: Farm }) {
  const [animalId, setAnimalId] = useState(animals[0]?.id ?? '');
  const [vaccine, setVaccine] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [next, setNext] = useState('');
  const [itemId, setItemId] = useState('');
  const [dose, setDose] = useState('');

  return (
    <div className="card">
      <h3 style={{ fontSize: 15, marginBottom: 10 }}>Record vaccination</h3>
      <div className="row field">
        <div><label style={lbl}>Animal</label>
          <select value={animalId} onChange={(e) => setAnimalId(e.target.value)}>
            {animals.map((a) => <option key={a.id} value={a.id}>{a.tag} {a.name ? `— ${a.name}` : ''}</option>)}
          </select>
        </div>
        <div><label style={lbl}>Vaccine</label>
          <input value={vaccine} onChange={(e) => setVaccine(e.target.value)} placeholder="e.g. FMD" />
        </div>
      </div>
      <div className="row field">
        <div><label style={lbl}>Date</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
        <div><label style={lbl}>Next due (optional)</label><input type="date" value={next} onChange={(e) => setNext(e.target.value)} /></div>
      </div>
      {medicines.length > 0 && (
        <div className="row field">
          <div><label style={lbl}>Medicine from stock (optional)</label>
            <select value={itemId} onChange={(e) => setItemId(e.target.value)}>
              <option value="">— none —</option>
              {medicines.map((m) => <option key={m.id} value={m.id}>{m.name} ({parseFloat(m.quantityOnHand).toFixed(1)} {m.unit})</option>)}
            </select>
          </div>
          <div><label style={lbl}>Dose</label><input type="number" step="0.01" value={dose} onChange={(e) => setDose(e.target.value)} /></div>
        </div>
      )}
      <button className="btn" onClick={async () => {
        if (!vaccine.trim() || !animalId) return;
        await post(`/farms/${farm.id}/health/vaccinations`, {
          animalId, vaccine: vaccine.trim(), date,
          nextDueDate: next || undefined,
          itemId: itemId || undefined,
          doseQty: dose ? parseFloat(dose) : undefined,
        });
        setVaccine(''); setNext(''); setDose('');
        onSaved();
      }}>Save vaccination</button>
    </div>
  );
}

function TreatmentForm({ animals, medicines, onSaved, farm }: { animals: Animal[]; medicines: InventoryItem[]; onSaved: () => void; farm: Farm }) {
  const [animalId, setAnimalId] = useState(animals[0]?.id ?? '');
  const [condition, setCondition] = useState('');
  const [medicine, setMedicine] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [withdrawal, setWithdrawal] = useState('0');
  const [followUp, setFollowUp] = useState('');
  const [itemId, setItemId] = useState('');
  const [dose, setDose] = useState('');

  return (
    <div className="card">
      <h3 style={{ fontSize: 15, marginBottom: 10 }}>Record treatment</h3>
      <div className="row field">
        <div><label style={lbl}>Animal</label>
          <select value={animalId} onChange={(e) => setAnimalId(e.target.value)}>
            {animals.map((a) => <option key={a.id} value={a.id}>{a.tag} {a.name ? `— ${a.name}` : ''}</option>)}
          </select>
        </div>
        <div><label style={lbl}>Condition</label><input value={condition} onChange={(e) => setCondition(e.target.value)} placeholder="e.g. Mastitis" /></div>
      </div>
      <div className="row field">
        <div><label style={lbl}>Medicine</label><input value={medicine} onChange={(e) => setMedicine(e.target.value)} placeholder="e.g. Penicillin" /></div>
        <div><label style={lbl}>Date</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
      </div>
      <div className="row field">
        <div><label style={lbl}>Withdrawal (days)</label><input type="number" value={withdrawal} onChange={(e) => setWithdrawal(e.target.value)} /></div>
        <div><label style={lbl}>Follow-up (optional)</label><input type="date" value={followUp} onChange={(e) => setFollowUp(e.target.value)} /></div>
      </div>
      {medicines.length > 0 && (
        <div className="row field">
          <div><label style={lbl}>Deduct from stock</label>
            <select value={itemId} onChange={(e) => setItemId(e.target.value)}>
              <option value="">— none —</option>
              {medicines.map((m) => <option key={m.id} value={m.id}>{m.name} ({parseFloat(m.quantityOnHand).toFixed(1)} {m.unit})</option>)}
            </select>
          </div>
          <div><label style={lbl}>Dose</label><input type="number" step="0.01" value={dose} onChange={(e) => setDose(e.target.value)} /></div>
        </div>
      )}
      <button className="btn" onClick={async () => {
        if (!condition.trim() || !medicine.trim() || !animalId) return;
        await post(`/farms/${farm.id}/health/treatments`, {
          animalId, condition: condition.trim(), medicine: medicine.trim(), date,
          withdrawalDays: Number(withdrawal) || 0,
          followUpDate: followUp || undefined,
          itemId: itemId || undefined,
          doseQty: dose ? parseFloat(dose) : undefined,
        });
        setCondition(''); setMedicine(''); setFollowUp(''); setDose('');
        onSaved();
      }}>Save treatment</button>
    </div>
  );
}

const lbl: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-soft)', marginBottom: 5 };
