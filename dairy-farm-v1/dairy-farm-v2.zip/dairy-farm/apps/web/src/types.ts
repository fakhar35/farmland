export type FarmMode = 'HERD' | 'INDIVIDUAL' | 'HYBRID';
export type RecordScope = 'HERD' | 'GROUP' | 'ANIMAL';

export interface Farm {
  id: string;
  name: string;
  mode: FarmMode;
  currencySymbol: string;
  milkPriceCents: number;
}

export interface HerdGroup {
  id: string; name: string; type: string; headcount: number;
  _count?: { animals: number };
}

export interface Animal {
  id: string; tag: string; name: string | null; breed: string | null;
  status: string; group?: { id: string; name: string } | null;
}

export interface DayTotals {
  date: string; milkLiters: number; soldLiters: number;
  revenueCents: number; feedCostCents: number; expenseCents: number; profitCents: number;
}

export interface DashboardPayload {
  today: DayTotals;
  series7d: DayTotals[];
  totalAnimals: number;
  milkingCount: number;
  unpaidCents: number;
  quarantinedTodayLiters: number;
  animalsUnderWithdrawal: number;
  remindersByKind: Array<{ kind: string; status: string; _count: number }>;
  lowStockCount: number;
}

export interface Customer {
  id: string; name: string; phone: string | null; email: string | null;
  priceCentsPerLiter: number | null; paymentTermsDays: number; active: boolean;
  outstandingCents?: number;
}

export interface Supplier {
  id: string; name: string; phone: string | null; email: string | null;
}

export type InventoryCategory = 'FEED' | 'MEDICINE' | 'EQUIPMENT' | 'CONSUMABLE' | 'OTHER';

export interface InventoryItem {
  id: string; name: string; category: InventoryCategory; unit: string;
  quantityOnHand: string; wacCents: number; reorderLevel: string | null;
}

export type InvoiceStatus = 'DRAFT' | 'OPEN' | 'PARTIAL' | 'PAID' | 'VOID';

export interface InvoiceListItem {
  id: string; number: string; issueDate: string; dueDate: string;
  status: InvoiceStatus; subtotalCents: number; paidCents: number;
  customer: { id: string; name: string };
  _count: { lines: number };
}

export interface Invoice extends Omit<InvoiceListItem, '_count'> {
  notes: string | null;
  lines: Array<{ id: string; description: string; quantity: string; unitCents: number; totalCents: number }>;
  payments: Array<{ id: string; date: string; amountCents: number; method: string | null }>;
  sales: Array<{ id: string; date: string; liters: string; priceCentsPerLiter: number }>;
}

export type ReminderKind =
  | 'VACCINATION' | 'TREATMENT_FOLLOWUP' | 'BREEDING_CHECK'
  | 'CALVING_DUE' | 'INVOICE_DUE' | 'LOW_STOCK' | 'CUSTOM';
export type ReminderStatus = 'PENDING' | 'DONE' | 'DISMISSED' | 'OVERDUE';

export interface Reminder {
  id: string; kind: ReminderKind; status: ReminderStatus;
  title: string; body: string | null; dueDate: string;
  entity: string | null; entityId: string | null; animalId: string | null;
}

export interface Vaccination {
  id: string; vaccine: string; date: string; nextDueDate: string | null;
  notes: string | null; animal: { id: string; tag: string; name: string | null };
}

export interface Treatment {
  id: string; condition: string; medicine: string; date: string;
  withdrawalDays: number; followUpDate: string | null; resolved: boolean;
  notes: string | null; animal: { id: string; tag: string; name: string | null };
}

export type BreedingEventKind =
  | 'HEAT' | 'INSEMINATION' | 'PREGNANCY_CHECK' | 'CALVING' | 'ABORTION' | 'DRY_OFF';

export interface BreedingEvent {
  id: string;
  kind: BreedingEventKind;
  date: string;
  nextDueDate: string | null;
  outcome: string | null;
  bullTag: string | null;
  notes: string | null;
  animal: { id: string; tag: string; name: string | null };
}
