import { useCallback, useEffect, useState } from 'react';
import { get, getToken, setToken } from './api';
import { Farm } from './types';
import AuthScreen from './screens/AuthScreen';
import FarmSetup from './screens/FarmSetup';
import Dashboard from './screens/Dashboard';
import RecordHub from './screens/RecordHub';
import Herd from './screens/Herd';
import Reports from './screens/Reports';
// V2
import Customers from './screens/Customers';
import Inventory from './screens/Inventory';
import Invoices from './screens/Invoices';
import Health from './screens/Health';
import Breeding from './screens/Breeding';
import Reminders from './screens/Reminders';

type Tab =
  | 'dashboard' | 'record' | 'herd' | 'reports'
  | 'customers' | 'inventory' | 'invoices' | 'health' | 'breeding' | 'reminders';

export default function App() {
  const [authed, setAuthed] = useState<boolean>(() => !!getToken());
  const [farm, setFarm] = useState<Farm | null>(null);
  const [loadingFarm, setLoadingFarm] = useState(false);
  const [tab, setTab] = useState<Tab>('dashboard');
  const [toast, setToast] = useState<string | null>(null);

  const notify = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  }, []);

  const loadFarm = useCallback(async () => {
    setLoadingFarm(true);
    try {
      const farms = await get<Farm[]>('/farms/mine');
      setFarm(farms[0] ?? null);
    } catch {
      setToken(null);
      setAuthed(false);
    } finally {
      setLoadingFarm(false);
    }
  }, []);

  useEffect(() => {
    if (authed) void loadFarm();
  }, [authed, loadFarm]);

  const logout = () => {
    setToken(null);
    setAuthed(false);
    setFarm(null);
  };

  if (!authed) return <AuthScreen onAuthed={() => setAuthed(true)} />;
  if (loadingFarm) return <div className="empty" style={{ paddingTop: 80 }}>Loading your farm…</div>;
  if (!farm) return <FarmSetup onCreated={(f) => setFarm(f)} />;

  // Tab set adapts to farm mode — HERD farms don't see health tab, since
  // it needs per-animal records. Reminders and finance modules apply everywhere.
  const baseTabs: [Tab, string][] = [
    ['dashboard', 'Dashboard'],
    ['record', 'Record'],
    ['herd', 'Herd'],
    ['reports', 'Reports'],
  ];
  const v2Tabs: [Tab, string][] = [
    ['customers', 'Customers'],
    ['invoices', 'Invoices'],
    ['inventory', 'Inventory'],
    ...(farm.mode !== 'HERD' ? [
      ['health', 'Health'] as [Tab, string],
      ['breeding', 'Breeding'] as [Tab, string],
    ] : []),
    ['reminders', 'Reminders'],
  ];
  const tabs = [...baseTabs, ...v2Tabs];

  return (
    <div className="app">
      <div className="top">
        <div className="farm">{farm.name}</div>
        <div className="right">
          <div className="mode">{farm.mode.toLowerCase()} mode</div>
          <button className="logout" onClick={logout}>Log out</button>
        </div>
      </div>
      <div className="nav nav-scroll">
        {tabs.map(([k, label]) => (
          <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>
            {label}
          </button>
        ))}
      </div>
      <div className="main">
        {tab === 'dashboard' && <Dashboard farm={farm} onNavigate={(t) => setTab(t as Tab)} />}
        {tab === 'record' && <RecordHub farm={farm} notify={notify} />}
        {tab === 'herd' && <Herd farm={farm} notify={notify} />}
        {tab === 'reports' && <Reports farm={farm} />}
        {tab === 'customers' && <Customers farm={farm} notify={notify} />}
        {tab === 'inventory' && <Inventory farm={farm} notify={notify} />}
        {tab === 'invoices' && <Invoices farm={farm} notify={notify} />}
        {tab === 'health' && <Health farm={farm} notify={notify} />}
        {tab === 'breeding' && <Breeding farm={farm} notify={notify} />}
        {tab === 'reminders' && <Reminders farm={farm} notify={notify} />}
      </div>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
